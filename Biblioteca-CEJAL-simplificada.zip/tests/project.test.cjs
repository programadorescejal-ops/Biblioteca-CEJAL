const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');

const root = path.resolve(__dirname, '..');
const publicDir = path.join(root, 'public');

function filesUnder(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const fullPath = path.join(directory, entry.name);
    return entry.isDirectory() ? filesUnder(fullPath) : [fullPath];
  });
}

test('todos os arquivos JavaScript têm sintaxe válida', () => {
  const scripts = filesUnder(path.join(publicDir, 'js')).filter((file) => file.endsWith('.js'));
  assert.ok(scripts.length > 0, 'nenhum script JavaScript encontrado');
  for (const script of scripts) {
    execFileSync(process.execPath, ['--check', script], { stdio: 'pipe' });
  }
});

test('cada página carrega seu script dedicado', () => {
  const pages = filesUnder(publicDir).filter((file) => file.endsWith('.html'));
  assert.ok(pages.length > 0, 'nenhuma página HTML encontrada');
  for (const page of pages) {
    const name = path.basename(page, '.html');
    const html = fs.readFileSync(page, 'utf8');
    const entry = `js/pages/${name}.js`;
    assert.ok(html.includes(`src="${entry}"`), `${name}.html não carrega ${entry}`);
    assert.ok(fs.existsSync(path.join(publicDir, entry)), `arquivo ausente: ${entry}`);
    assert.doesNotMatch(html, /<script\b(?![^>]*\bsrc\s*=)[^>]*>/i, `${name}.html ainda contém JavaScript inline`);
  }
});

test('referências locais em páginas HTML apontam para arquivos existentes', () => {
  const pages = filesUnder(publicDir).filter((file) => file.endsWith('.html'));
  const attribute = /\b(?:src|href)\s*=\s*["']([^"']+)["']/gi;
  for (const page of pages) {
    const html = fs.readFileSync(page, 'utf8');
    for (const match of html.matchAll(attribute)) {
      const reference = match[1];
      if (/^(?:[a-z]+:|\/\/|#)/i.test(reference)) continue;
      const pathname = decodeURIComponent(reference.split(/[?#]/, 1)[0]);
      assert.ok(fs.existsSync(path.resolve(path.dirname(page), pathname)), `${path.basename(page)} referencia arquivo ausente: ${reference}`);
    }
  }
});

test('a raiz redireciona ao login antes de servir index.html', () => {
  const config = JSON.parse(fs.readFileSync(path.join(root, 'firebase.json'), 'utf8'));
  assert.ok(config.hosting.redirects?.some((rule) => rule.regex === '^/$' && rule.destination === '/login.html'));
});

test('índices Firestore cobrem as consultas compostas usadas pelo app', () => {
  const config = JSON.parse(fs.readFileSync(path.join(root, 'firebase', 'firestore.indexes.json'), 'utf8'));
  const signatures = config.indexes.map((index) => `${index.collectionGroup}:${index.fields.map((field) => `${field.fieldPath}:${field.order}`).join(',')}`);
  for (const expected of [
    'emprestimos:aluno_id:ASCENDING,status:ASCENDING',
    'emprestimos:aluno_id:ASCENDING,status:ASCENDING,data_devolucao_real:DESCENDING',
    'emprestimos:aluno_id:ASCENDING,data_emprestimo:DESCENDING',
    'emprestimos:aluno_id:ASCENDING,livro_id:ASCENDING,status:ASCENDING',
    'solicitacoes_emprestimo:aluno_id:ASCENDING,livro_id:ASCENDING,status:ASCENDING',
    'emprestimos:livro_id:ASCENDING,aluno_id:ASCENDING,status:ASCENDING',
    'reservas:livro_id:ASCENDING,status:ASCENDING',
    'reservas:aluno_id:ASCENDING,livro_id:ASCENDING,status:ASCENDING',
    'reservas:aluno_id:ASCENDING,status:ASCENDING',
    'notificacoes:aluno_id:ASCENDING,data_criacao:DESCENDING',
    'notificacoes:aluno_id:ASCENDING,lida:ASCENDING'
  ]) assert.ok(signatures.includes(expected), `índice ausente: ${expected}`);
});

test('configuração Firebase aponta para arquivos existentes', () => {
  const config = JSON.parse(fs.readFileSync(path.join(root, 'firebase.json'), 'utf8'));
  const firestoreConfigs = Array.isArray(config.firestore) ? config.firestore : [config.firestore];
  assert.ok(firestoreConfigs.some((entry) => entry.database === 'default'), 'deve apontar para o banco Firestore nomeado default');
  for (const entry of firestoreConfigs) {
    for (const file of [entry.rules, entry.indexes]) {
    assert.ok(fs.existsSync(path.join(root, file)), `arquivo Firebase ausente: ${file}`);
    }
  }
  assert.equal(config.functions, undefined, 'plano Spark não usa Cloud Functions');
});

test('não há dependência de Cloud Functions no cliente', () => {
  const clients = filesUnder(path.join(publicDir, 'js')).filter((file) => file.endsWith('.js'));
  const source = clients.map((file) => fs.readFileSync(file, 'utf8')).join('\n');
  assert.doesNotMatch(source, /httpsCallable|firebaseFunctions/);
  assert.doesNotMatch(filesUnder(publicDir).filter(file => file.endsWith('.html')).map(file => fs.readFileSync(file, 'utf8')).join('\n'), /firebase-functions-compat/);
  assert.ok(fs.existsSync(path.join(publicDir, 'js', 'core', 'solicitacoes.js')));
});
