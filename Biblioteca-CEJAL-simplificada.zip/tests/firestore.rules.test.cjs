const assert = require('node:assert/strict');
const { initializeTestEnvironment, assertSucceeds, assertFails } = require('@firebase/rules-unit-testing');
const { collection, deleteDoc, doc, getDoc, getDocs, query, serverTimestamp, setDoc, Timestamp, updateDoc, where } = require('firebase/firestore');
const fs = require('node:fs');
const path = require('node:path');
const { before, beforeEach, after, test } = require('node:test');

const root = path.resolve(__dirname, '..');
let environment;

function student(uid, matricula) {
  return {
    nome: `Aluno ${uid}`,
    matricula,
    email: `${matricula}@escola.com`,
    serie: '1º ano',
    turma: 'A',
    livros_atuais: [],
    historico: [],
    bloqueado: false,
    motivo_bloqueio: null,
    data_cadastro: Timestamp.now(),
    total_lidos: 0,
    badges: [],
    ultimo_acesso: Timestamp.now(),
    senha_padrao: false
  };
}

before(async () => {
  environment = await initializeTestEnvironment({
    projectId: 'demo-biblioteca',
    firestore: {
      host: '127.0.0.1',
      port: 8080,
      rules: fs.readFileSync(path.join(root, 'firebase', 'firestore.rules'), 'utf8')
    }
  });
});

after(async () => {
  await environment?.cleanup();
});

beforeEach(async () => {
  await environment.clearFirestore();
  await environment.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await Promise.all([
      setDoc(doc(db, 'admins', 'admin-1'), { nome: 'Bibliotecário', role: 'admin' }),
      setDoc(doc(db, 'alunos', 'student-1'), student('student-1', '2026001')),
      setDoc(doc(db, 'alunos', 'student-2'), student('student-2', '2026002')),
      setDoc(doc(db, 'livros', 'book-1'), { titulo: 'Livro A', quantidade_total: 3, quantidade_disponivel: 2 }),
      setDoc(doc(db, 'emprestimos', 'loan-1'), { aluno_id: 'student-1', livro_id: 'book-1', status: 'ativo' }),
      setDoc(doc(db, 'emprestimos', 'loan-2'), { aluno_id: 'student-2', livro_id: 'book-1', status: 'ativo' }),
      setDoc(doc(db, 'reservas', 'book-1_student-1'), { aluno_id: 'student-1', livro_id: 'book-1', status: 'ativa' }),
      setDoc(doc(db, 'reservas', 'book-1_student-2'), { aluno_id: 'student-2', livro_id: 'book-1', status: 'ativa' }),
      setDoc(doc(db, 'notificacoes', 'notice-1'), { aluno_id: 'student-1', lida: false }),
      setDoc(doc(db, 'notificacoes', 'notice-2'), { aluno_id: 'student-2', lida: false })
    ]);
  });
});

test('catálogo é público e alterações exigem admin', async () => {
  const anonymousDb = environment.unauthenticatedContext().firestore();
  const studentDb = environment.authenticatedContext('student-1').firestore();
  await assertSucceeds(getDoc(doc(anonymousDb, 'livros', 'book-1')));
  await assertSucceeds(getDocs(collection(studentDb, 'livros')));
  await assertFails(updateDoc(doc(studentDb, 'livros', 'book-1'), { quantidade_disponivel: 99 }));
});

test('aluno lê e edita o próprio perfil sem alterar campos de controle', async () => {
  const db = environment.authenticatedContext('student-1').firestore();
  await assertSucceeds(getDoc(doc(db, 'alunos', 'student-1')));
  await assertFails(getDoc(doc(db, 'alunos', 'student-2')));
  await assertFails(getDocs(collection(db, 'alunos')));
  await assertSucceeds(updateDoc(doc(db, 'alunos', 'student-1'), { nome: 'Nome atualizado' }));
  await assertFails(updateDoc(doc(db, 'alunos', 'student-1'), { bloqueado: true }));
  await assertFails(updateDoc(doc(db, 'alunos', 'student-1'), { livros_atuais: ['book-1'] }));
});

test('aluno só consulta próprios empréstimos; criação e alteração exigem admin', async () => {
  const db = environment.authenticatedContext('student-1').firestore();
  await assertSucceeds(getDoc(doc(db, 'emprestimos', 'loan-1')));
  await assertFails(getDoc(doc(db, 'emprestimos', 'loan-2')));
  await assertSucceeds(getDocs(query(collection(db, 'emprestimos'), where('aluno_id', '==', 'student-1'))));
  await assertFails(getDocs(collection(db, 'emprestimos')));
  await assertFails(setDoc(doc(db, 'emprestimos', 'forged'), { aluno_id: 'student-1', status: 'ativo' }));
});

test('aluno cria e cancela apenas a própria solicitação de empréstimo', async () => {
  const db = environment.authenticatedContext('student-1').firestore();
  const requestRef = doc(db, 'solicitacoes_emprestimo', 'request-1');
  await assertSucceeds(setDoc(requestRef, {
    aluno_id: 'student-1', aluno_nome: 'Aluno student-1', livro_id: 'book-1',
    titulo_livro: 'Livro A', status: 'pendente', data_solicitacao: serverTimestamp()
  }));
  await assertFails(updateDoc(requestRef, { status: 'aprovada' }));
  await assertSucceeds(updateDoc(requestRef, { status: 'cancelada', data_cancelamento: serverTimestamp() }));
  await assertSucceeds(setDoc(doc(db, 'solicitacoes_emprestimo', 'request-2'), {
    aluno_id: 'student-1', aluno_nome: 'Aluno student-1', livro_id: 'book-1',
    titulo_livro: 'Livro A', status: 'pendente', data_solicitacao: serverTimestamp()
  }));
  await assertFails(setDoc(doc(db, 'solicitacoes_emprestimo', 'forged'), {
    aluno_id: 'student-2', aluno_nome: 'Outro', livro_id: 'book-1',
    titulo_livro: 'Livro A', status: 'pendente', data_solicitacao: serverTimestamp()
  }));
  await assertFails(getDoc(doc(db, 'solicitacoes_emprestimo', 'request-other')));
});

test('aluno só cria e cancela a própria reserva; fila completa é admin-only', async () => {
  const studentDb = environment.authenticatedContext('student-1').firestore();
  const adminDb = environment.authenticatedContext('admin-1').firestore();
  const ref = doc(studentDb, 'reservas', 'book-1_student-1');
  await assertSucceeds(setDoc(ref, {
    livro_id: 'book-1', aluno_id: 'student-1', titulo_livro: 'Livro A',
    aluno_nome: 'Aluno student-1', status: 'ativa', data_reserva: serverTimestamp()
  }));
  await assertFails(getDocs(collection(studentDb, 'reservas')));
  await assertSucceeds(getDocs(collection(adminDb, 'reservas')));
  await assertSucceeds(updateDoc(ref, { status: 'cancelada', data_cancelamento: serverTimestamp() }));
  await assertFails(updateDoc(doc(studentDb, 'reservas', 'book-1_student-2'), { status: 'cancelada', data_cancelamento: serverTimestamp() }));
});

test('reservas e notificações ficam limitadas ao aluno; admin mantém visão completa', async () => {
  const studentDb = environment.authenticatedContext('student-1').firestore();
  const adminDb = environment.authenticatedContext('admin-1').firestore();
  await assertSucceeds(getDoc(doc(studentDb, 'reservas', 'book-1_student-1')));
  await assertFails(getDoc(doc(studentDb, 'reservas', 'book-1_student-2')));
  await assertSucceeds(getDocs(query(collection(studentDb, 'reservas'), where('aluno_id', '==', 'student-1'))));
  await assertFails(getDocs(collection(studentDb, 'reservas')));
  await assertSucceeds(getDocs(collection(adminDb, 'reservas')));
  await assertSucceeds(getDoc(doc(studentDb, 'notificacoes', 'notice-1')));
  await assertFails(getDoc(doc(studentDb, 'notificacoes', 'notice-2')));
  await assertSucceeds(updateDoc(doc(studentDb, 'notificacoes', 'notice-1'), { lida: true, data_leitura: Timestamp.now() }));
  await assertFails(updateDoc(doc(studentDb, 'notificacoes', 'notice-2'), { lida: true, data_leitura: Timestamp.now() }));
  await assertFails(deleteDoc(doc(studentDb, 'notificacoes', 'notice-1')));
});

test('admin gerencia registros, mas não cria outro admin pelo cliente', async () => {
  const db = environment.authenticatedContext('admin-1').firestore();
  await assertSucceeds(getDocs(collection(db, 'alunos')));
  await assertSucceeds(updateDoc(doc(db, 'alunos', 'student-2'), { bloqueado: true }));
  await assertSucceeds(setDoc(doc(db, 'emprestimos', 'loan-admin'), { aluno_id: 'student-2', status: 'ativo' }));
  await assertFails(setDoc(doc(db, 'admins', 'admin-2'), { role: 'admin' }));
});

test('cadastro próprio só cria perfil inicial não privilegiado', async () => {
  const db = environment.authenticatedContext('student-new', { email: '2026003@escola.com' }).firestore();
  await assertSucceeds(setDoc(doc(db, 'alunos', 'student-new'), student('student-new', '2026003')));
  await assertFails(setDoc(doc(db, 'alunos', 'student-new'), { ...student('student-new', '2026003'), bloqueado: true }));
});
