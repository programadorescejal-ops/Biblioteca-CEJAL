import { createRemoteJWKSet, jwtVerify } from 'jose';

const FIREBASE_JWKS = createRemoteJWKSet(new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'));
const ALLOWED_ORIGINS = new Set([
  'https://biblioteca-7daf5.web.app',
  'https://biblioteca-7daf5.firebaseapp.com',
  'http://localhost:5000',
  'http://127.0.0.1:5000'
]);

function response(body, status, origin) {
  return new Response(body, {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type',
      'Vary': 'Origin'
    }
  });
}

function json(data, status, origin) {
  return response(JSON.stringify(data), status, origin);
}

async function requireAdmin(request, env) {
  const authorization = request.headers.get('Authorization') || '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  if (!token) throw new Error('Autenticação necessária.');

  const { payload } = await jwtVerify(token, FIREBASE_JWKS, {
    issuer: `https://securetoken.google.com/${env.FIREBASE_PROJECT_ID}`,
    audience: env.FIREBASE_PROJECT_ID
  });
  const uid = payload.sub;
  if (!uid) throw new Error('Token de usuário inválido.');

  const path = `https://firestore.googleapis.com/v1/projects/${env.FIREBASE_PROJECT_ID}/databases/${env.FIRESTORE_DATABASE || 'default'}/documents/admins/${encodeURIComponent(uid)}`;
  const adminDoc = await fetch(path, { headers: { Authorization: `Bearer ${token}` } });
  if (!adminDoc.ok) throw new Error('Somente administradores podem gerar capas.');
  return uid;
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    if (!ALLOWED_ORIGINS.has(origin)) return new Response('Origin not allowed', { status: 403 });
    if (request.method === 'OPTIONS') return response(null, 204, origin);
    if (request.method !== 'POST' || new URL(request.url).pathname !== '/generate-cover') {
      return json({ error: 'Rota não encontrada.' }, 404, origin);
    }

    try {
      await requireAdmin(request, env);
      const input = await request.json();
      const title = String(input.title || '').trim().slice(0, 120);
      const author = String(input.author || '').trim().slice(0, 120);
      const genre = String(input.genre || 'Literatura').trim().slice(0, 80);
      if (!title || !author) return json({ error: 'Título e autor são obrigatórios.' }, 400, origin);

      const prompt = [
        'Create one original, polished illustrated book-cover artwork, portrait 2:3 composition.',
        `Book title: ${JSON.stringify(title)}. Author: ${JSON.stringify(author)}. Genre: ${JSON.stringify(genre)}.`,
        'Use the title and genre only as inspiration for the visual scene. Do not include any letters, words, title text, logos, publisher marks, borders, or watermarks; the app adds the book text separately.',
        'Create original imagery. Do not imitate an existing publisher cover or depict recognizable copyrighted characters. Make the subject clear, visually rich, suitable for a school library, and readable as a small thumbnail.'
      ].join('\n');

      const generation = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite-image:generateContent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: {
            responseModalities: ['IMAGE'],
            imageConfig: { aspectRatio: '2:3', imageSize: '512' }
          }
        })
      });
      if (!generation.ok) {
        const detail = await generation.json().catch(() => ({}));
        console.error('Gemini image generation failed', generation.status, detail.error?.status || 'unknown');
        return json({ error: 'O serviço de geração de capas não conseguiu criar a imagem.' }, 502, origin);
      }

      const result = await generation.json();
      const image = result.candidates?.flatMap(candidate => candidate.content?.parts || [])
        .find(part => part.inlineData?.data && /^image\/(png|jpeg|webp)$/.test(part.inlineData.mimeType || ''))?.inlineData;
      if (!image) return json({ error: 'A IA não retornou uma imagem. Tente novamente.' }, 502, origin);
      if (image.data.length > 6_000_000) return json({ error: 'A imagem gerada excedeu o limite permitido.' }, 502, origin);
      return json({ imageBase64: image.data, mimeType: image.mimeType }, 200, origin);
    } catch (error) {
      const message = error?.code === 'ERR_JWT_INVALID' || error?.code === 'ERR_JWS_SIGNATURE_VERIFICATION_FAILED'
        ? 'Sessão inválida. Entre novamente.'
        : (error.message || 'Falha ao gerar a capa.');
      const status = message.includes('administradores') || message.includes('Sessão') || message.includes('Token') || message.includes('Autenticação') ? 401 : 500;
      console.error('Cover worker error:', error?.code || error?.name || 'Error');
      return json({ error: message }, status, origin);
    }
  }
};
