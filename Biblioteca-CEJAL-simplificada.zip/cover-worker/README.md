# Serviço de capas com IA (Firebase Spark)

O Cloudflare Worker guarda a chave Gemini fora do site, valida o token Firebase e exige que o usuário tenha documento em `admins/{uid}` antes de gerar uma imagem. Ele só é chamado quando o catálogo Open Library não encontra capa publicada.

## Publicar

1. Instale Node.js e crie uma conta Cloudflare.
2. Nesta pasta, execute `npm install` e `npx wrangler login`.
3. Crie uma chave Gemini no Google AI Studio com faturamento habilitado. A geração de imagem não possui faixa grátis e cobra por imagem.
4. Execute `npx wrangler secret put GEMINI_API_KEY` e cole a chave no prompt local do terminal. Não coloque a chave no código nem no chat.
5. Execute `npx wrangler deploy` e copie a URL `https://biblioteca-cejal-capas.<conta>.workers.dev` exibida.
6. Abra Administração → Livros → Novo Livro → Configurar geração de capas por IA e informe a URL. Ela fica salva apenas no armazenamento local desse navegador.

O catálogo tenta localizar a capa publicada primeiro. Se não encontrar e a URL do Worker estiver configurada, a IA cria arte original inspirada no título/autor/gênero. O app compõe o texto da capa, converte para WebP 420×630 e salva o resultado no campo `capaUrl` do livro no Firestore. Sem correspondência nem Worker configurado, usa `default-cover.png`.

O Worker usa `gemini-3.1-flash-lite-image` em 512 px. O preço publicado atualmente equivale a cerca de US$ 0,0336 por imagem 1K; confira a tabela atual antes de gerar em escala.
