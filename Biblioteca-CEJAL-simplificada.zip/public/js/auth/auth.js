// ============================================
// SISTEMA DE AUTENTICAÇÃO
// Biblioteca CEJAL
// ============================================

class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.userData = null;
        this.listeners = [];

        // Monitora estado da autenticação
        auth.onAuthStateChanged(async (user) => {
            if (user) {
                this.currentUser = user;
                try {
                    await this.loadUserData(user.uid);
                } catch (_) {
                    // Admin (ou conta sem perfil) não tem documento em "alunos": é normal
                    this.userData = null;
                }
                this.notifyListeners('login', this.userData);
            } else {
                this.currentUser = null;
                this.userData = null;
                this.notifyListeners('logout', null);
            }
        });
    }

    // ============================================
    // LOGIN COM MATRÍCULA
    // ============================================
    async login(matricula, senha) {
        try {
            const email = `${matricula.trim()}@escola.com`;
            const userCredential = await auth.signInWithEmailAndPassword(email, senha);
            const user = userCredential.user;

            // Verifica se é admin
            const adminDoc = await db.collection('admins').doc(user.uid).get();
            if (adminDoc.exists) {
                this.userData = { ...adminDoc.data(), role: 'admin' };
                this.notifyListeners('admin-login', this.userData);
                return { success: true, role: 'admin', data: this.userData };
            }

            // Carrega dados do aluno
            await this.loadUserData(user.uid);
            return { success: true, role: 'aluno', data: this.userData };

        } catch (error) {
            console.error('Erro no login:', error);
            return {
                success: false,
                error: this.getErrorMessage(error.code)
            };
        }
    }

    // ============================================
    // CADASTRO DE ALUNO
    // ============================================
    async cadastrarAluno(dados) {
        const { nome, serie, turma, senha, confirmarSenha } = dados;
        const matriculaNormalizada = String(dados.matricula || '').trim();

        // Validações
        if (!/^\d{5,10}$/.test(matriculaNormalizada)) {
            return { success: false, error: 'Matrícula deve ter de 5 a 10 números' };
        }

        if (senha !== confirmarSenha) {
            return { success: false, error: 'Senhas não coincidem' };
        }

        if (senha.length < 6) {
            return { success: false, error: 'Senha deve ter no mínimo 6 caracteres' };
        }

        let secondaryAuth = null;
        let novoUsuario = null;
        try {
            // Pré-checagem de matrícula duplicada (opcional: o Auth também recusa e-mail repetido)
            try {
                const existingAluno = await db.collection('alunos')
                    .where('matricula', '==', matriculaNormalizada)
                    .get();
                if (!existingAluno.empty) {
                    return { success: false, error: 'Matrícula já cadastrada' };
                }
            } catch (_) { /* sem permissão para consultar: segue, o Auth valida */ }

            // Usa app secundário para NÃO deslogar o admin atual
            const email = `${matriculaNormalizada}@escola.com`;
            let secondaryApp;
            try {
                secondaryApp = firebase.app('Secondary');
            } catch (e) {
                secondaryApp = firebase.initializeApp(firebase.app().options, 'Secondary');
            }
            secondaryAuth = secondaryApp.auth();
            const secondaryRawFirestore = secondaryApp.container.getProvider('firestore').getImmediate({ identifier: 'default' });
            const secondaryDb = new firebase.firestore.Firestore(secondaryApp, secondaryRawFirestore, null);
            if (['localhost', '127.0.0.1'].includes(window.location.hostname)) {
                try { secondaryAuth.useEmulator('http://127.0.0.1:9099'); } catch (_) {}
                try { secondaryDb.useEmulator('127.0.0.1', 8080); } catch (_) {}
            }
            const userCredential = await secondaryAuth.createUserWithEmailAndPassword(email, senha);
            const user = userCredential.user;
            novoUsuario = user;

            const alunoData = {
                nome: nome.trim(),
                matricula: matriculaNormalizada,
                email: email,
                serie: serie,
                turma: turma,
                livros_atuais: [],
                historico: [],
                bloqueado: false,
                motivo_bloqueio: null,
                data_cadastro: serverTimestamp(),
                total_lidos: 0,
                badges: [],
                ultimo_acesso: serverTimestamp(),
                senha_padrao: !!dados.senhaPadrao
            };

            // Admin logado grava como admin; cadastro público grava como o próprio aluno recém-criado
            const writeDb = auth.currentUser ? db : secondaryDb;
            await writeDb.collection('alunos').doc(user.uid).set(alunoData);

            // Desloga só a sessão secundária (admin continua logado)
            try { await secondaryAuth.signOut(); } catch (_) {}

            return {
                success: true,
                user: user,
                data: alunoData
            };

        } catch (error) {
            console.error('Erro no cadastro:', error);
            // Não deixa conta "órfã" no Auth sem documento em alunos
            if (novoUsuario) { try { await novoUsuario.delete(); } catch (_) {} }
            if (secondaryAuth) { try { await secondaryAuth.signOut(); } catch (_) {} }
            return {
                success: false,
                error: this.getErrorMessage(error.code)
            };
        }
    }

    // ============================================
    // ALTERAR SENHA (o próprio aluno, confirmando a senha atual)
    // ============================================
    async alterarSenha(senhaAtual, novaSenha) {
        const user = auth.currentUser;
        if (!user) return { success: false, error: 'Faça login novamente' };
        if (!novaSenha || novaSenha.length < 6) {
            return { success: false, error: 'A nova senha deve ter no mínimo 6 caracteres' };
        }
        if (novaSenha === senhaAtual) {
            return { success: false, error: 'A nova senha deve ser diferente da atual' };
        }

        try {
            const credencial = firebase.auth.EmailAuthProvider.credential(user.email, senhaAtual);
            await user.reauthenticateWithCredential(credencial);
            await user.updatePassword(novaSenha);
            try {
                await db.collection('alunos').doc(user.uid).update({ senha_padrao: false });
            } catch (_) { /* a senha já foi trocada; o aviso some no próximo acesso */ }
            return { success: true };
        } catch (error) {
            console.error('Erro ao alterar senha:', error);
            const senhaErrada = ['auth/wrong-password', 'auth/invalid-credential', 'auth/invalid-login-credentials'].includes(error.code);
            return { success: false, error: senhaErrada ? 'Senha atual incorreta' : this.getErrorMessage(error.code) };
        }
    }

    // ============================================
    // LOGOUT
    // ============================================
    async logout() {
        try {
            await auth.signOut();
            return { success: true };
        } catch (error) {
            console.error('Erro no logout:', error);
            return { success: false, error: error.message };
        }
    }

    // ============================================
    // RECUPERAÇÃO DE SENHA
    // ============================================
    async resetPassword(matricula) {
        try {
            const email = `${matricula.trim()}@escola.com`;
            await auth.sendPasswordResetEmail(email);
            return {
                success: true,
                message: 'Email de recuperação enviado'
            };
        } catch (error) {
            return {
                success: false,
                error: this.getErrorMessage(error.code)
            };
        }
    }

    // ============================================
    // CARREGA DADOS DO USUÁRIO
    // ============================================
    async loadUserData(uid) {
        try {
            const doc = await db.collection('alunos').doc(uid).get();
            if (doc.exists) {
                this.userData = { id: uid, ...doc.data() };
                return this.userData;
            }
            throw new Error('Usuário não encontrado');
        } catch (error) {
            console.error('Erro ao carregar dados do usuário:', error);
            throw error;
        }
    }

    // ============================================
    // SISTEMA DE LISTENERS
    // ============================================
    addListener(callback) {
        this.listeners.push(callback);
        return () => {
            this.listeners = this.listeners.filter(cb => cb !== callback);
        };
    }

    notifyListeners(event, data) {
        this.listeners.forEach(callback => {
            try {
                callback(event, data);
            } catch (error) {
                console.error('Erro no listener:', error);
            }
        });
    }

    // ============================================
    // TRADUÇÃO DE ERROS
    // ============================================
    getErrorMessage(code) {
        const errors = {
            'auth/user-not-found': 'Usuário não encontrado',
            'auth/wrong-password': 'Senha incorreta',
            'auth/email-already-in-use': 'Matrícula já cadastrada',
            'auth/invalid-credential': 'Matrícula ou senha inválidos',
            'auth/invalid-login-credentials': 'Matrícula ou senha inválidos',
            'permission-denied': 'Sem permissão para esta ação',
            'auth/requires-recent-login': 'Por segurança, saia e entre de novo antes de trocar a senha',
            'auth/invalid-email': 'Email inválido',
            'auth/weak-password': 'Senha muito fraca',
            'auth/too-many-requests': 'Muitas tentativas, tente depois',
            'auth/user-disabled': 'Usuário desativado',
            'auth/network-request-failed': 'Erro de conexão com a internet'
        };
        return errors[code] || 'Erro desconhecido';
    }
}

// ============================================
// INSTÂNCIA GLOBAL
// ============================================
const authSystem = new AuthSystem();
window.authSystem = authSystem;
