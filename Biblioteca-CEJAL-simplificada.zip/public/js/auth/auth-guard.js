// ============================================
// GUARD DE AUTENTICAÇÃO - PROTEÇÃO DE ROTAS
// Biblioteca CEJAL
//
// Ponto ÚNICO de decisão de papel (admin / aluno).
// Todas as páginas usam as mesmas funções, então
// não existe mais "uma página acha que é admin e
// outra acha que é aluno" (causa do loop antigo).
// ============================================

class AuthGuard {
    // ============================================
    // AGUARDA O FIREBASE RESTAURAR A SESSÃO
    // ============================================
    getCurrentUser() {
        return new Promise((resolve) => {
            const unsubscribe = auth.onAuthStateChanged((user) => {
                unsubscribe();
                resolve(user);
            });
        });
    }

    async verifyAuth() {
        return !!(await this.getCurrentUser());
    }

    // ============================================
    // DESCOBRE O PAPEL DO USUÁRIO
    //  'admin'      -> existe em admins/{uid}
    //  'aluno'      -> existe em alunos/{uid}
    //  'sem-perfil' -> logado no Auth, mas sem documento
    //  null         -> não logado
    // ============================================
    async getRole(user) {
        if (!user) return null;

        const adminDoc = await db.collection('admins').doc(user.uid).get();
        if (adminDoc.exists) return 'admin';

        const alunoDoc = await db.collection('alunos').doc(user.uid).get();
        if (alunoDoc.exists) return 'aluno';

        return 'sem-perfil';
    }

    // Página inicial de cada papel
    destinoPorRole(role) {
        if (role === 'admin') return 'admin.html';
        if (role === 'aluno') return 'index.html';
        return null;
    }

    // ============================================
    // REDIRECIONAMENTO COM PROTEÇÃO CONTRA LOOP
    // Se houver 5+ redirecionamentos em 6s, para tudo,
    // desloga e mostra o erro na tela de login.
    // ============================================
    _loopDetectado() {
        try {
            const agora = Date.now();
            const lista = JSON.parse(sessionStorage.getItem('cejal_redir') || '[]')
                .filter((t) => agora - t < 6000);
            lista.push(agora);
            sessionStorage.setItem('cejal_redir', JSON.stringify(lista));
            return lista.length >= 5;
        } catch (_) {
            return false;
        }
    }

    ir(url) {
        if (this._loopDetectado()) {
            console.error('Loop de redirecionamento detectado. Encerrando sessão.');
            try { sessionStorage.removeItem('cejal_redir'); } catch (_) {}
            auth.signOut().finally(() => window.location.replace('login.html?erro=loop'));
            return;
        }
        window.location.replace(url);
    }

    // Desloga e volta ao login mostrando um motivo
    async sairComErro(codigo) {
        try { await auth.signOut(); } catch (_) {}
        window.location.replace('login.html?erro=' + encodeURIComponent(codigo));
    }

    // ============================================
    // EXIGE LOGIN
    // ============================================
    async requireAuth() {
        const user = await this.getCurrentUser();
        if (!user) {
            this.ir('login.html');
            return false;
        }
        return true;
    }

    // ============================================
    // EXIGE ADMIN (usado em admin.html)
    // ============================================
    async requireAdmin() {
        const user = await this.getCurrentUser();
        if (!user) {
            this.ir('login.html');
            return false;
        }

        try {
            const role = await this.getRole(user);

            if (role === 'admin') return true;

            if (role === 'aluno') {          // aluno tentando abrir o painel
                this.ir('index.html');
                return false;
            }

            // Logado, mas sem documento em admins/ nem alunos/
            console.warn('Conta sem perfil. UID:', user.uid,
                '-> para torná-la admin, crie o documento admins/' + user.uid + ' no Firestore.');
            await this.sairComErro('sem-perfil');
            return false;
        } catch (error) {
            console.error('Erro ao verificar admin:', error);
            await this.sairComErro('falha-verificacao');
            return false;
        }
    }

    // ============================================
    // EXIGE ALUNO (usado em index.html e perfil.html)
    // Retorna os dados do aluno, ou null se redirecionou.
    // ============================================
    async requireAluno({ permitirAdmin = false } = {}) {
        const user = await this.getCurrentUser();
        if (!user) {
            this.ir('login.html');
            return null;
        }

        try {
            const role = await this.getRole(user);

            if (role === 'admin') {
                if (permitirAdmin) {
                    // Admin navegando pela área do aluno: só visualização, sem empréstimos
                    return {
                        id: user.uid,
                        nome: 'Administrador',
                        role: 'admin',
                        modoAdmin: true,
                        livros_atuais: [],
                        historico: []
                    };
                }
                this.ir('admin.html');
                return null;
            }

            if (role !== 'aluno') {
                console.warn('Conta sem perfil de aluno. UID:', user.uid);
                await this.sairComErro('sem-perfil');
                return null;
            }

            const dados = await authSystem.loadUserData(user.uid);
            if (!dados || !dados.nome) {
                await this.sairComErro('perfil-incompleto');
                return null;
            }
            return dados;
        } catch (error) {
            console.error('Erro ao verificar aluno:', error);
            // Não desloga: pode ser só queda de internet
            window.location.replace('login.html?erro=falha-verificacao');
            return null;
        }
    }

    // ============================================
    // LOGIN: SE JÁ ESTIVER LOGADO, VAI PARA O PAINEL CERTO
    // ============================================
    async redirectIfLoggedIn() {
        const user = await this.getCurrentUser();
        if (!user) return false;

        try {
            const destino = this.destinoPorRole(await this.getRole(user));
            if (destino) {
                this.ir(destino);
                return true;
            }
        } catch (e) {
            console.warn(e);
        }
        return false;
    }
}

// ============================================
// INSTÂNCIA GLOBAL
// ============================================
const authGuard = new AuthGuard();
window.authGuard = authGuard;
