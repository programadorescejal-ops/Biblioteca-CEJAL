// ============================================
// Serviço de busca de capas publicadas - Biblioteca CEJAL
// ============================================

class GoogleBooksService {
    constructor() {
    }

    async buscarCapa(titulo, autor = null, genero = 'Biblioteca') {
        try {
            const capaEncontrada = await window.buscarCapaCatalogo(titulo, autor);
            if (capaEncontrada) return capaEncontrada;
            return await window.gerarCapaComIA(titulo, autor, genero) || this.fallback();
        } catch (error) {
            console.error('Erro ao localizar capa publicada:', error);
            throw error;
        }
    }

    fallback() {
        return 'assets/images/default-cover.png';
    }
}

const googleBooksService = new GoogleBooksService();
window.googleBooksService = googleBooksService;
