// ============================================
// CONQUISTAS (BADGES) - Biblioteca CEJAL
//
// Calculadas a partir dos empréstimos do aluno (coleção "emprestimos",
// consulta só por aluno_id: não exige índice composto) e gravadas em
// alunos/{id}.badges como lista de IDs.
// ============================================

class ConquistasSystem {
    static get BADGES() {
        const genero = (nome) => (m) => [m.porGenero[nome] || 0, 5];
        return [
            { id: 'primeiro_emprestimo', icone: '🌟', nome: 'Primeiro Empréstimo', descricao: 'Pegou seu primeiro livro', medida: (m) => [m.totalEmprestimos, 1] },
            { id: 'leitor_iniciante',    icone: '📚', nome: 'Leitor Iniciante',    descricao: 'Leu 3 livros',  medida: (m) => [m.totalLidos, 3] },
            { id: 'leitor_avido',        icone: '📖', nome: 'Leitor Ávido',        descricao: 'Leu 10 livros', medida: (m) => [m.totalLidos, 10] },
            { id: 'mestre_livros',       icone: '🏆', nome: 'Mestre dos Livros',   descricao: 'Leu 30 livros', medida: (m) => [m.totalLidos, 30] },
            { id: 'lenda_biblioteca',    icone: '📜', nome: 'Lenda da Biblioteca', descricao: 'Leu 50 livros', medida: (m) => [m.totalLidos, 50] },
            { id: 'devolucao_rapida',    icone: '⚡', nome: 'Devolução no Prazo',  descricao: 'Devolveu 3 livros dentro do prazo', medida: (m) => [m.noPrazo, 3] },
            { id: 'leitor_persistente',  icone: '🔥', nome: 'Leitor Persistente',  descricao: '30 dias de biblioteca e 5 livros lidos', medida: (m) => [Math.min(m.dias, 30) + Math.min(m.totalLidos, 5), 35] },
            { id: 'explorador_fantasia', icone: '🐉', nome: 'Explorador de Fantasia', descricao: 'Leu 5 livros de Fantasia', medida: genero('Fantasia') },
            { id: 'viajante_espacial',   icone: '🚀', nome: 'Viajante Espacial',   descricao: 'Leu 5 livros de Ficção Científica', medida: genero('Ficção Científica') },
            { id: 'leitor_brasileiro',   icone: '🇧🇷', nome: 'Leitor Brasileiro',  descricao: 'Leu 5 livros de Literatura Brasileira', medida: genero('Literatura Brasileira') },
            { id: 'leitor_classicos',    icone: '🎭', nome: 'Leitor de Clássicos', descricao: 'Leu 5 livros de Drama, Romance ou Lit. Brasileira',
              medida: (m) => [(m.porGenero['Drama'] || 0) + (m.porGenero['Romance'] || 0) + (m.porGenero['Literatura Brasileira'] || 0), 5] }
        ];
    }

    _data(t) {
        if (!t) return null;
        const d = t.toDate ? t.toDate() : new Date(t);
        return isNaN(d.getTime()) ? null : d;
    }

    // Já tem a conquista? (aceita ID novo ou o nome antigo gravado por versões anteriores)
    _tem(badgesAluno, badge) {
        return (badgesAluno || []).some(b => b === badge.id || String(b).includes(badge.nome));
    }

    async _metricas(alunoId, aluno) {
        const [empSnap, livrosSnap] = await Promise.all([
            db.collection('emprestimos').where('aluno_id', '==', alunoId).get(),
            db.collection('livros').get()
        ]);

        const generos = {};
        livrosSnap.forEach(d => { generos[d.id] = d.data().genero; });

        const emprestimos = empSnap.docs.map(d => d.data());
        const devolvidos = emprestimos.filter(e => e.status === 'devolvido');

        const porGenero = {};
        let noPrazo = 0;
        devolvidos.forEach(e => {
            const g = e.genero_livro || generos[e.livro_id];
            if (g) porGenero[g] = (porGenero[g] || 0) + 1;
            const prevista = this._data(e.data_devolucao_prevista);
            const real = this._data(e.data_devolucao_real);
            if (prevista && real && real <= prevista) noPrazo++;
        });

        const cadastro = this._data(aluno.data_cadastro);
        return {
            totalEmprestimos: emprestimos.length,
            totalLidos: Math.max(aluno.total_lidos || 0, devolvidos.length),
            noPrazo,
            porGenero,
            dias: cadastro ? Math.floor((Date.now() - cadastro.getTime()) / 86400000) : 0
        };
    }

    // Recalcula, grava as conquistas novas e devolve o quadro completo.
    async verificar(alunoId) {
        const alunoRef = db.collection('alunos').doc(alunoId);
        const alunoDoc = await alunoRef.get();
        if (!alunoDoc.exists) return { novas: [], todas: [] };
        const aluno = alunoDoc.data();

        const m = await this._metricas(alunoId, aluno);
        const todas = ConquistasSystem.BADGES.map(b => {
            const [progresso, total] = b.medida(m);
            return { ...b, progresso: Math.min(progresso, total), total, ok: progresso >= total };
        });

        return { novas: [], todas, earned: todas.filter(b => b.ok) };
    }
}

const conquistasSystem = new ConquistasSystem();
window.conquistasSystem = conquistasSystem;
