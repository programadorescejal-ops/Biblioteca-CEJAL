// Localiza capas publicadas no Open Library; não cria ilustrações que possam ser confundidas com a edição real.
(function () {
    const normalizar = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    const cacheKey = (title, author) => `capa-real-v2:${normalizar(title)}:${normalizar(author)}`;
    const capaPadrao = 'assets/images/default-cover.png';

    window.urlCapaLivro = function (livro) {
        const url = String(livro?.capaUrl || '').trim();
        return /^https:\/\//i.test(url) || /^data:image\/webp;base64,/i.test(url) ? url : capaPadrao;
    };

    async function buscarCapaCatalogo(title, author) {
        const key = cacheKey(title, author);
        try {
            const cached = JSON.parse(localStorage.getItem(key) || 'null');
            if (cached && cached.expira > Date.now()) return cached.url || null;
        } catch (_) {}

        let cover = null;
        try {
            const query = new URLSearchParams({ title, author: author || '', fields: 'title,author_name,cover_i,language', limit: '30' });
            const response = await fetch(`https://openlibrary.org/search.json?${query}`, { signal: AbortSignal.timeout(6000) });
            if (response.ok) {
                const data = await response.json();
                const wantedTitle = normalizar(title);
                const wantedAuthor = normalizar(author);
                const candidates = (data.docs || []).filter(book => book.cover_i && book.title).map(book => {
                    const foundTitle = normalizar(book.title);
                    const authors = (book.author_name || []).map(normalizar);
                    const titleMatches = foundTitle === wantedTitle || foundTitle.includes(wantedTitle) || wantedTitle.includes(foundTitle);
                    const authorMatches = !wantedAuthor || authors.some(name => name === wantedAuthor || name.includes(wantedAuthor) || wantedAuthor.includes(name));
                    if (!titleMatches || !authorMatches) return null;
                    let score = foundTitle === wantedTitle ? 100 : 45;
                    if (authorMatches && wantedAuthor) score += 35;
                    if ((book.language || []).includes('por')) score += 8;
                    score -= Math.min(20, Math.abs(foundTitle.length - wantedTitle.length) / 4);
                    return { cover: book.cover_i, score };
                }).filter(Boolean).sort((a, b) => b.score - a.score);
                if (candidates.length && candidates[0].score >= 70) {
                    cover = `https://covers.openlibrary.org/b/id/${candidates[0].cover}-L.jpg`;
                }
            }
        } catch (_) {}

        try {
            localStorage.setItem(key, JSON.stringify({ url: cover, expira: Date.now() + (cover ? 30 : 1) * 86400000 }));
        } catch (_) {}
        return cover;
    }
    window.buscarCapaCatalogo = buscarCapaCatalogo;

    function ajustarCapaParaFirestore(base64, mimeType, title, author, genre) {
        return new Promise((resolve, reject) => {
            const image = new Image();
            image.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = 420;
                canvas.height = 630;
                const context = canvas.getContext('2d');
                const scale = Math.max(canvas.width / image.width, canvas.height / image.height);
                const width = image.width * scale;
                const height = image.height * scale;
                context.drawImage(image, (canvas.width - width) / 2, (canvas.height - height) / 2, width, height);
                const gradient = context.createLinearGradient(0, 260, 0, 630);
                gradient.addColorStop(0, 'rgba(0,0,0,0)');
                gradient.addColorStop(1, 'rgba(0,0,0,.82)');
                context.fillStyle = gradient;
                context.fillRect(0, 250, 420, 380);
                context.fillStyle = '#fff';
                context.shadowColor = 'rgba(0,0,0,.55)';
                context.shadowBlur = 5;
                context.font = '700 16px Arial';
                context.fillText(String(genre || 'LIVRO').toLocaleUpperCase('pt-BR').slice(0, 28), 30, 510, 360);
                let fontSize = 38;
                const titleText = String(title || 'Livro sem título').slice(0, 100);
                while (fontSize > 22) {
                    context.font = `700 ${fontSize}px Georgia`;
                    if (context.measureText(titleText).width <= 360) break;
                    fontSize -= 2;
                }
                context.font = `700 ${fontSize}px Georgia`;
                const words = titleText.split(/\s+/);
                const titleLines = [];
                let line = '';
                for (const word of words) {
                    const next = line ? `${line} ${word}` : word;
                    if (context.measureText(next).width > 360 && line) { titleLines.push(line); line = word; }
                    else line = next;
                }
                if (line) titleLines.push(line);
                const shownLines = titleLines.slice(0, 3);
                const firstY = 566 - (shownLines.length - 1) * (fontSize + 4);
                shownLines.forEach((part, index) => context.fillText(part, 30, firstY + index * (fontSize + 4), 360));
                context.font = '18px Arial';
                context.fillText(String(author || '').slice(0, 70), 30, 610, 360);
                context.shadowBlur = 0;
                const result = canvas.toDataURL('image/webp', 0.76);
                if (!result.startsWith('data:image/webp;base64,') || result.length > 650000) {
                    reject(new Error('A capa gerada excedeu o limite de tamanho do Firestore.'));
                    return;
                }
                resolve(result);
            };
            image.onerror = () => reject(new Error('A IA retornou uma imagem inválida.'));
            image.src = `data:${mimeType};base64,${base64}`;
        });
    }

    window.gerarCapaComIA = async function (title, author, genre) {
        const endpoint = String(localStorage.getItem('bibliotecaCapaIaEndpoint') || '').trim();
        if (!endpoint) return null;
        const user = window.firebase?.auth?.().currentUser;
        if (!user) throw new Error('Entre como administrador para gerar capas com IA.');
        const token = await user.getIdToken();
        const response = await fetch(`${endpoint.replace(/\/$/, '')}/generate-cover`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ title, author, genre })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || `Erro no serviço de capas (${response.status}).`);
        return ajustarCapaParaFirestore(data.imageBase64, data.mimeType, title, author, genre);
    };

    window.completarCapaLivro = async function (image) {
        if (!image || image.dataset.buscaCapa === '1') return;
        image.dataset.buscaCapa = '1';
        const cover = await buscarCapaCatalogo(image.dataset.titulo, image.dataset.autor);
        if (!image.isConnected) return;
        if (cover) {
            image.onerror = () => {
                image.onerror = null;
                image.src = capaPadrao;
            };
            image.src = cover;
        } else {
            image.onerror = null;
            image.src = capaPadrao;
        }
    };

    function completarCapas(root) {
        root.querySelectorAll('img[data-titulo][src^="data:image/svg+xml"], img[data-titulo][src*="default-cover.png"]').forEach(image => {
            window.completarCapaLivro(image);
        });
    }

    if (document.body) {
        new MutationObserver(() => completarCapas(document)).observe(document.body, { childList: true, subtree: true });
        completarCapas(document);
    }
})();
