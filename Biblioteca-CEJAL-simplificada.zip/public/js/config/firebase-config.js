// ============================================
// CONFIGURAÇÃO DO FIREBASE - Biblioteca CEJAL
// ============================================

const firebaseConfig = {
    apiKey: "AIzaSyCa3GLXc6lZtA7rgYCq3Y2v0T79TeyLvnI",
    authDomain: "biblioteca-7daf5.firebaseapp.com",
    projectId: "biblioteca-7daf5",
    messagingSenderId: "1057472290636",
    appId: "1:1057472290636:web:fd98eadc18a152dbe4b9e9"
};

firebase.initializeApp(firebaseConfig);

// Este projeto já possui o banco nomeado "default" (não o banco especial "(default)").
// O wrapper Compat conserva a API antiga do app usando o delegate da instância nomeada.
const firestoreProvider = firebase.app().container.getProvider('firestore');
const namedFirestore = firestoreProvider.getImmediate({ identifier: 'default' });
const db = new firebase.firestore.Firestore(firebase.app(), namedFirestore, null);
const auth = firebase.auth();

const localHost = ['localhost', '127.0.0.1'].includes(window.location.hostname);

// O servidor local usa exclusivamente emuladores; nunca grava por engano no projeto real.
if (localHost) {
    auth.useEmulator('http://127.0.0.1:9099');
    db.useEmulator('127.0.0.1', 8080);
}
// Arrow function evita "Cannot access before initialization"
const serverTimestamp = () => firebase.firestore.FieldValue.serverTimestamp();
const FieldValue = firebase.firestore.FieldValue;

window.db = db;
window.auth = auth;
window.serverTimestamp = serverTimestamp;
window.FieldValue = FieldValue;

console.log('Firebase OK | Projeto:', firebaseConfig.projectId);
