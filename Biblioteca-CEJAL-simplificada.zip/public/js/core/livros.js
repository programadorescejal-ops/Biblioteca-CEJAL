// ============================================
// SISTEMA DE LIVROS - Biblioteca CEJAL
// ============================================

// Normaliza o documento: livros criados à mão no console (sem alguns campos)
// também aparecem e funcionam no catálogo.
function normalizarLivro(id, d) {
    const num = (v) => (typeof v === 'number' && isFinite(v)) ? v : null;
    const total = num(d.quantidade_total) ?? num(d.quantidade) ?? 1;
    const disp = num(d.quantidade_disponivel) ?? total;
    return {
        ...d,
        id,
        titulo: d.titulo || d.Titulo || '(sem título)',
        autor: d.autor || 'Autor desconhecido',
        genero: d.genero || 'Outros',
        quantidade_total: total,
        quantidade_disponivel: Math.max(0, disp)
    };
}
window.normalizarLivro = normalizarLivro;

class LivrosSystem {
    constructor() {
        this.livros = [];
        this.listeners = [];
        this.unsubscribe = null;
    }

    listarLivrosEmTempoReal(filtro = null, callback = null, onError = null) {
        if (this.unsubscribe) this.unsubscribe();

        // Sem orderBy no servidor: o Firestore DESCARTA documentos que não têm o
        // campo ordenado. Ordenamos aqui no navegador, então nenhum livro some.
        let query = db.collection('livros');

        if (filtro && filtro.genero) {
            query = query.where('genero', '==', filtro.genero);
        }

        this.unsubscribe = query.onSnapshot((snapshot) => {
            let livros = [];
            snapshot.forEach((doc) => {
                livros.push(normalizarLivro(doc.id, doc.data()));
            });

            if (filtro && filtro.busca) {
                const t = filtro.busca.toLowerCase();
                livros = livros.filter(l =>
                    l.titulo.toLowerCase().includes(t) ||
                    l.autor.toLowerCase().includes(t) ||
                    l.genero.toLowerCase().includes(t)
                );
            }

            livros.sort((a, b) => a.titulo.localeCompare(b.titulo, 'pt-BR', { sensitivity: 'base' }));

            this.livros = livros;
            this.notifyListeners(livros);
            if (callback) callback(livros);

        }, (error) => {
            console.error('Erro ao listar livros:', error);
            if (onError) onError(error);
        });

        return this.unsubscribe;
    }

    // Lista única (sem tempo real), usada pelo painel admin
    async listarLivros() {
        const snapshot = await db.collection('livros').get();
        const livros = [];
        snapshot.forEach((doc) => livros.push(normalizarLivro(doc.id, doc.data())));
        livros.sort((a, b) => a.titulo.localeCompare(b.titulo, 'pt-BR', { sensitivity: 'base' }));
        return livros;
    }

    async adicionarLivro(dados) {
        try {
            const { titulo, autor, genero } = dados;
            const quantidade = Math.max(1, parseInt(dados.quantidade, 10) || 1);
            if (!titulo || !titulo.trim() || !autor || !autor.trim()) {
                return { success: false, error: 'Informe título e autor' };
            }
            let capaUrl = 'assets/images/default-cover.png';

            try {
                if (typeof googleBooksService !== 'undefined') {
                    const capa = await googleBooksService.buscarCapa(titulo, autor, genero);
                    if (capa) capaUrl = capa;
                }
            } catch (e) {
                console.warn('Não foi possível localizar ou gerar uma capa; usando a capa padrão.', e);
            }

            const livroData = {
                titulo: titulo.trim(),
                autor: autor.trim(),
                genero: genero || 'Outros',
                capaUrl: capaUrl,
                disponivel: true,
                quantidade_total: quantidade,
                quantidade_disponivel: quantidade,
                emprestado_para: [],
                data_cadastro: serverTimestamp(),
                titulo_busca: titulo.trim().toLowerCase(),
                total_emprestimos: 0
            };

            const docRef = await db.collection('livros').add(livroData);
            return { success: true, id: docRef.id, data: livroData };
        } catch (error) {
            console.error('Erro ao adicionar livro:', error);
            return { success: false, error: error.message };
        }
    }

    async removerLivro(livroId) {
        try {
            const livroRef = db.collection('livros').doc(livroId);
            const livroDoc = await livroRef.get();

            if (!livroDoc.exists) {
                return { success: false, error: 'Livro não encontrado' };
            }

            const livro = livroDoc.data();
            const n = normalizarLivro(livroId, livro);
            if (n.quantidade_disponivel < n.quantidade_total) {
                return { success: false, error: 'Livro está emprestado, não pode ser removido' };
            }

            await livroRef.delete();
            return { success: true };
        } catch (error) {
            console.error('Erro ao remover livro:', error);
            return { success: false, error: error.message };
        }
    }

    // ============================================
    // EMPRÉSTIMO ATÔMICO (tudo dentro da transaction)
    // ============================================
    async pegarEmprestimo(livroId) {
        try {
            return await window.solicitacoesEmprestimoSystem.solicitar(livroId);
        } catch (error) {
            console.error('Erro no empréstimo:', error);
            return { success: false, error: error.message || 'Não foi possível registrar o empréstimo.' };
        }
    }
    // Confere conquistas depois de emprestar/devolver (nunca quebra a operação principal)
    async _verificarConquistas(alunoId) {
        try {
            if (window.conquistasSystem) {
                const r = await conquistasSystem.verificar(alunoId);
                return r.novas;
            }
        } catch (e) {
            console.warn('Conquistas não verificadas:', e);
        }
        return [];
    }

    // ============================================
    // DEVOLUÇÃO (query FORA da transaction)
    // ============================================
    async devolverLivro(livroId, alunoId) {
        try {
            const currentUid = firebase.auth().currentUser?.uid;
            const targetUid = alunoId || currentUid;
            const empQuery = db.collection('emprestimos').where('livro_id', '==', livroId)
                .where('aluno_id', '==', targetUid).where('status', '==', 'ativo').limit(1);
            const empSnap = await empQuery.get();
            if (empSnap.empty) throw new Error('Empréstimo não encontrado.');
            const empRef = empSnap.docs[0].ref;
            return await db.runTransaction(async (tx) => {
                const [empDoc, bookSnap, studentSnap] = await Promise.all([
                    tx.get(empRef), tx.get(db.collection('livros').doc(livroId)),
                    tx.get(db.collection('alunos').doc(targetUid))
                ]);
                if (!empDoc.exists || empDoc.data().status !== 'ativo' || !bookSnap.exists || !studentSnap.exists) throw new Error('Empréstimo não encontrado.');
                const book = bookSnap.data();
                const student = studentSnap.data();
                const total = Number(book.quantidade_total ?? book.quantidade ?? 1);
                const available = Number(book.quantidade_disponivel ?? total);
                const now = firebase.firestore.Timestamp.now();
                tx.update(empDoc.ref, { status: 'devolvido', data_devolucao_real: now });
                tx.update(bookSnap.ref, {
                    quantidade_disponivel: Math.min(total, available + 1),
                    emprestado_para: (Array.isArray(book.emprestado_para) ? book.emprestado_para : []).filter(id => id !== targetUid)
                });
                tx.update(studentSnap.ref, {
                    livros_atuais: (student.livros_atuais || []).filter(id => id !== livroId),
                    historico: [...(student.historico || []), livroId],
                    total_lidos: (Number(student.total_lidos) || 0) + 1
                });
                return { success: true };
            });
        } catch (error) {
            console.error('Erro na devolução:', error);
            return { success: false, error: error.message || 'Não foi possível registrar a devolução.' };
        }
    }
    async verificarAtrasos() {
        const hoje = new Date();
        const emprestimosAtrasados = [];

        try {
            const snapshot = await db.collection('emprestimos')
                .where('status', '==', 'ativo')
                .get();

            for (const doc of snapshot.docs) {
                const emprestimo = doc.data();
                const raw = emprestimo.data_devolucao_prevista;
                const dataDevolucao = raw && raw.toDate ? raw.toDate() : new Date(raw);
                if (!dataDevolucao || isNaN(dataDevolucao.getTime())) continue;

                if (dataDevolucao < hoje) {
                    const alunoDoc = await db.collection('alunos').doc(emprestimo.aluno_id).get();
                    emprestimosAtrasados.push({
                        id: doc.id,
                        ...emprestimo,
                        aluno: alunoDoc.exists ? alunoDoc.data() : null,
                        dias_atraso: Math.floor((hoje - dataDevolucao) / (1000 * 60 * 60 * 24))
                    });
                }
            }
            return emprestimosAtrasados;
        } catch (error) {
            console.error('Erro ao verificar atrasos:', error);
            return [];
        }
    }

    addListener(callback) {
        this.listeners.push(callback);
        return () => {
            this.listeners = this.listeners.filter(cb => cb !== callback);
        };
    }

    notifyListeners(livros) {
        this.listeners.forEach(callback => {
            try { callback(livros); } catch (error) {
                console.error('Erro no listener:', error);
            }
        });
    }
}

const livrosSystem = new LivrosSystem();
window.livrosSystem = livrosSystem;
