// Solicitações de empréstimo: o aluno solicita; o administrador confirma.
class SolicitacoesEmprestimoSystem {
    observarMinhas(uid, callback, onError) {
        this.unsubscribe?.();
        this.unsubscribe = db.collection('solicitacoes_emprestimo').where('aluno_id', '==', uid).onSnapshot(snapshot => {
            callback?.(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        }, error => onError?.(error));
        return this.unsubscribe;
    }

    async solicitar(livroId) {
        try {
            const uid = firebase.auth().currentUser?.uid;
            if (!uid) throw new Error('Faça login para solicitar um empréstimo.');
            const [studentSnap, bookSnap, active, pending] = await Promise.all([
                db.collection('alunos').doc(uid).get(),
                db.collection('livros').doc(livroId).get(),
                db.collection('emprestimos').where('aluno_id', '==', uid).where('livro_id', '==', livroId).where('status', '==', 'ativo').limit(1).get(),
                db.collection('solicitacoes_emprestimo').where('aluno_id', '==', uid).where('livro_id', '==', livroId).where('status', '==', 'pendente').limit(1).get()
            ]);
            if (!studentSnap.exists || !bookSnap.exists) throw new Error('Aluno ou livro não encontrado.');
            if (studentSnap.data().bloqueado) throw new Error('Sua conta está bloqueada. Procure a biblioteca.');
            if (!active.empty) throw new Error('Você já está com este livro emprestado.');
            if (!pending.empty) throw new Error('Você já tem uma solicitação pendente para este livro.');
            const book = bookSnap.data();
            const ref = db.collection('solicitacoes_emprestimo').doc();
            await ref.set({
                aluno_id: uid,
                aluno_nome: studentSnap.data().nome || '',
                livro_id: livroId,
                titulo_livro: book.titulo || '(sem título)',
                status: 'pendente',
                data_solicitacao: firebase.firestore.FieldValue.serverTimestamp()
            });
            return { success: true, id: ref.id };
        } catch (error) {
            return { success: false, error: error.message || 'Não foi possível enviar a solicitação.' };
        }
    }

    async listarMinhas() {
        const uid = firebase.auth().currentUser?.uid;
        if (!uid) return [];
        const snap = await db.collection('solicitacoes_emprestimo').where('aluno_id', '==', uid).get();
        return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    }

    async listarPendentes() {
        const snap = await db.collection('solicitacoes_emprestimo').where('status', '==', 'pendente').get();
        return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    }

    async cancelar(id) {
        try {
            const uid = firebase.auth().currentUser?.uid;
            const ref = db.collection('solicitacoes_emprestimo').doc(id);
            await db.runTransaction(async tx => {
                const snap = await tx.get(ref);
                if (!snap.exists || snap.data().aluno_id !== uid || snap.data().status !== 'pendente') throw new Error('Solicitação não pode ser cancelada.');
                tx.update(ref, { status: 'cancelada', data_cancelamento: firebase.firestore.FieldValue.serverTimestamp() });
            });
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async aprovar(id) {
        try {
            const requestRef = db.collection('solicitacoes_emprestimo').doc(id);
            const loanRef = db.collection('emprestimos').doc();
            const requestSnapOutside = await requestRef.get();
            if (!requestSnapOutside.exists || requestSnapOutside.data().status !== 'pendente') throw new Error('Solicitação não está pendente.');
            const requestOutside = requestSnapOutside.data();
            const activeQuery = db.collection('emprestimos').where('aluno_id', '==', requestOutside.aluno_id).where('status', '==', 'ativo');
            const queueQuery = db.collection('reservas').where('livro_id', '==', requestOutside.livro_id).where('status', '==', 'ativa');
            const [activeSnap, queueSnap] = await Promise.all([activeQuery.get(), queueQuery.get()]);
            const queue = queueSnap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.data_reserva?.toMillis?.() || 0) - (b.data_reserva?.toMillis?.() || 0));
            const result = await db.runTransaction(async tx => {
                const requestSnap = await tx.get(requestRef);
                if (!requestSnap.exists || requestSnap.data().status !== 'pendente') throw new Error('Solicitação não está pendente.');
                const request = requestSnap.data();
                const studentRef = db.collection('alunos').doc(request.aluno_id);
                const bookRef = db.collection('livros').doc(request.livro_id);
                const firstReservationRef = queue.length ? db.collection('reservas').doc(queue[0].id) : null;
                const [studentSnap, bookSnap, firstReservationSnap] = await Promise.all([
                    tx.get(studentRef), tx.get(bookRef),
                    firstReservationRef ? tx.get(firstReservationRef) : Promise.resolve(null)
                ]);
                if (!studentSnap.exists || !bookSnap.exists) throw new Error('Aluno ou livro não encontrado.');
                const student = studentSnap.data();
                const book = bookSnap.data();
                if (student.bloqueado) throw new Error('Aluno bloqueado.');
                const loans = activeSnap.docs.map(d => d.data());
                const currentBooks = Array.isArray(student.livros_atuais) ? student.livros_atuais : [];
                if (currentBooks.includes(request.livro_id) || loans.some(e => e.livro_id === request.livro_id)) throw new Error('Aluno já está com este livro.');
                if (Math.max(loans.length, currentBooks.length) >= 3) throw new Error('Aluno já atingiu o limite de 3 livros.');
                if (loans.some(e => {
                    const raw = e.data_devolucao_prevista;
                    const dueDate = raw?.toDate ? raw.toDate() : new Date(raw);
                    return !Number.isNaN(dueDate.getTime()) && dueDate < new Date();
                })) throw new Error('Aluno tem empréstimo atrasado.');
                const total = Number(book.quantidade_total ?? book.quantidade ?? 1);
                const available = Number(book.quantidade_disponivel ?? total);
                if (!Number.isFinite(total) || !Number.isFinite(available) || available <= 0) throw new Error('Não há exemplares disponíveis.');
                if (queue.length && queue[0].aluno_id !== request.aluno_id) throw new Error('Há reserva anterior. Atenda primeiro a fila de reservas.');
                if (queue.length && (!firstReservationSnap?.exists || firstReservationSnap.data().status !== 'ativa' || firstReservationSnap.data().aluno_id !== request.aluno_id)) {
                    throw new Error('A fila mudou. Atualize a lista e tente novamente.');
                }
                const now = firebase.firestore.Timestamp.now();
                const due = new Date(now.toDate());
                due.setDate(due.getDate() + 7);
                tx.update(bookRef, {
                    quantidade_total: total,
                    quantidade_disponivel: Math.min(total, available) - 1,
                    emprestado_para: firebase.firestore.FieldValue.arrayUnion(request.aluno_id),
                    total_emprestimos: (Number(book.total_emprestimos) || 0) + 1
                });
                tx.update(studentRef, {
                    livros_atuais: [...new Set([...currentBooks, request.livro_id])],
                    ultimo_emprestimo: now
                });
                tx.set(loanRef, {
                    livro_id: request.livro_id,
                    aluno_id: request.aluno_id,
                    titulo_livro: book.titulo || request.titulo_livro,
                    genero_livro: book.genero || null,
                    data_emprestimo: now,
                    data_devolucao_prevista: firebase.firestore.Timestamp.fromDate(due),
                    data_devolucao_real: null,
                    status: 'ativo',
                    renovado: false
                });
                tx.update(requestRef, { status: 'aprovada', data_aprovacao: now });
                if (queue.length && queue[0].aluno_id === request.aluno_id) tx.update(db.collection('reservas').doc(queue[0].id), { status: 'atendida', data_atendida: now });
                return { dataDevolucao: due.toISOString() };
            });
            return { success: true, ...result };
        } catch (error) {
            return { success: false, error: error.message || 'Não foi possível aprovar a solicitação.' };
        }
    }

    async recusar(id) {
        try {
            await db.collection('solicitacoes_emprestimo').doc(id).update({ status: 'recusada', data_recusa: firebase.firestore.FieldValue.serverTimestamp() });
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
}

window.solicitacoesEmprestimoSystem = new SolicitacoesEmprestimoSystem();
