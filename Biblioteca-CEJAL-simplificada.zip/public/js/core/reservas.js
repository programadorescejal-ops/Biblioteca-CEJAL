// Reservas no Spark: o aluno vê e cancela a própria; o administrador vê e ordena a fila.
class ReservasSystem {
    constructor() {
        this.ativas = [];
        this.unsubscribe = null;
        this.alunoId = null;
        this.modoAdmin = false;
    }

    _sort(rows) {
        return rows.sort((a, b) => {
            const left = a.data_reserva?.toMillis?.() || 0;
            const right = b.data_reserva?.toMillis?.() || 0;
            return left - right || a.id.localeCompare(b.id);
        });
    }

    observarAtivas(callback, onError) {
        this.unsubscribe?.();
        this.modoAdmin = true;
        this.alunoId = null;
        this.unsubscribe = db.collection('reservas').where('status', '==', 'ativa').onSnapshot(snapshot => {
            this.ativas = this._sort(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            callback?.(this.ativas);
        }, error => onError?.(error));
        return this.unsubscribe;
    }

    observarMinhasAtivas(uid, callback, onError) {
        this.unsubscribe?.();
        this.modoAdmin = false;
        this.alunoId = uid;
        this.unsubscribe = db.collection('reservas').where('aluno_id', '==', uid).where('status', '==', 'ativa').onSnapshot(snapshot => {
            this.ativas = this._sort(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            callback?.(this.ativas);
        }, error => onError?.(error));
        return this.unsubscribe;
    }

    async listarAtivas() {
        const uid = firebase.auth().currentUser?.uid;
        if (!uid) throw new Error('Faça login para consultar reservas.');
        const admin = await db.collection('admins').doc(uid).get();
        this.modoAdmin = admin.exists;
        this.alunoId = admin.exists ? null : uid;
        let query = db.collection('reservas').where('status', '==', 'ativa');
        if (!admin.exists) query = query.where('aluno_id', '==', uid);
        const snapshot = await query.get();
        this.ativas = this._sort(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        return this.ativas;
    }

    async listarMinhasAtivas(uid) {
        if (firebase.auth().currentUser?.uid !== uid) throw new Error('Consulta restrita à sessão atual.');
        const snapshot = await db.collection('reservas').where('aluno_id', '==', uid).where('status', '==', 'ativa').get();
        this.ativas = this._sort(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        return this.ativas;
    }

    fila(bookId, rows = this.ativas) {
        return rows.filter(row => row.livro_id === bookId);
    }

    posicao(bookId, uid, rows = this.ativas) {
        if (!this.modoAdmin) return 0;
        const index = this.fila(bookId, rows).findIndex(row => row.aluno_id === uid);
        return index < 0 ? 0 : index + 1;
    }

    podePegar(book, uid) {
        return this.modoAdmin || Number(book.quantidade_disponivel) > 0;
    }

    async reservar(bookId) {
        try {
            const uid = firebase.auth().currentUser?.uid;
            if (!uid) throw new Error('Faça login para reservar.');
            const studentSnap = await db.collection('alunos').doc(uid).get();
            const bookSnap = await db.collection('livros').doc(bookId).get();
            const existing = await db.collection('reservas').where('aluno_id', '==', uid).where('livro_id', '==', bookId).where('status', '==', 'ativa').limit(1).get();
            if (!studentSnap.exists || !bookSnap.exists) throw new Error('Aluno ou livro não encontrado.');
            if (studentSnap.data().bloqueado) throw new Error('Sua conta está bloqueada.');
            if (!existing.empty) throw new Error('Você já tem uma reserva ativa para este livro.');
            const book = bookSnap.data();
            const ref = db.collection('reservas').doc(`${bookId}_${uid}`);
            const current = await ref.get();
            const reservation = {
                livro_id: bookId,
                aluno_id: uid,
                titulo_livro: book.titulo || '(sem título)',
                aluno_nome: studentSnap.data().nome || '',
                status: 'ativa',
                data_reserva: firebase.firestore.FieldValue.serverTimestamp()
            };
            if (current.exists) {
                if (!['cancelada', 'atendida'].includes(current.data().status)) throw new Error('Você já tem uma reserva ativa para este livro.');
                await ref.set(reservation);
            } else {
                await ref.set(reservation);
            }
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message || 'Não foi possível reservar.' };
        }
    }

    async cancelar(bookId, uid) {
        if (firebase.auth().currentUser?.uid !== uid) return { success: false, error: 'Sessão inválida.' };
        return this.cancelarPorId(`${bookId}_${uid}`);
    }

    async cancelarPorId(id) {
        try {
            const uid = firebase.auth().currentUser?.uid;
            const ref = db.collection('reservas').doc(id);
            await db.runTransaction(async tx => {
                const snap = await tx.get(ref);
                if (!snap.exists || snap.data().aluno_id !== uid || snap.data().status !== 'ativa') throw new Error('Reserva não pode ser cancelada.');
                tx.update(ref, { status: 'cancelada', data_cancelamento: firebase.firestore.FieldValue.serverTimestamp() });
            });
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message || 'Não foi possível cancelar.' };
        }
    }
}

window.reservasSystem = new ReservasSystem();
