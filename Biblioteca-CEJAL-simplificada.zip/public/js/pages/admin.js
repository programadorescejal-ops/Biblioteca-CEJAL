// ============================================
        // INICIALIZAÇÃO
        // ============================================
        document.addEventListener('DOMContentLoaded', async () => {
            // Exige login E papel de admin (coleção admins)
            const isAdmin = await authGuard.requireAdmin();
            if (!isAdmin) return;
            
            carregarDashboard();
            carregarEmprestimos();
            setupEventListeners();
        });

        // ============================================
        // FUNÇÕES AUXILIARES
        // ============================================
        function formatarData(timestamp) {
            if (!timestamp) return 'N/A';
            try {
                const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
                return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
            } catch { return 'Data inválida'; }
        }

        function diasAtraso(data) {
            const d = data && data.toDate ? data.toDate() : new Date(data);
            return Math.max(1, Math.floor((new Date() - d) / 86400000));
        }

        // Busca + "só atrasados", combinados
        function aplicarFiltroEmprestimos() {
            const termo = (document.getElementById('searchEmprestimos')?.value || '').toLowerCase();
            const soAtrasados = !!document.getElementById('filtroAtrasados')?.checked;
            document.querySelectorAll('.emprestimo-card').forEach(card => {
                const okTexto = card.textContent.toLowerCase().includes(termo);
                const okAtraso = !soAtrasados || card.dataset.atrasado === '1';
                card.style.display = (okTexto && okAtraso) ? '' : 'none';
            });
        }

        function isAtrasado(data) {
            if (!data) return false;
            const hoje = new Date();
            const devolucao = data.toDate ? data.toDate() : new Date(data);
            return devolucao < hoje;
        }

        function showToast(message, type = 'info') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.innerHTML = `
                <div class="toast-icon"><i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i></div>
                <div class="toast-message">${message}</div>
                <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
            `;
            container.appendChild(toast);
            setTimeout(() => toast.remove(), 4000);
        }

        function fecharModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }

        // ============================================
        // DASHBOARD
        // ============================================
        async function carregarDashboard() {
            try {
                const livros = await db.collection('livros').get();
                document.getElementById('totalLivros').textContent = livros.size;
                
                const emprestimos = await db.collection('emprestimos').where('status','==','ativo').get();
                document.getElementById('emprestimosAtivos').textContent = emprestimos.size;
                
                let atrasados = 0;
                emprestimos.forEach(d => { if (isAtrasado(d.data().data_devolucao_prevista)) atrasados++; });
                document.getElementById('emprestimosAtrasados').textContent = atrasados;
                
                const bloqueados = await db.collection('alunos').where('bloqueado','==',true).get();
                document.getElementById('alunosBloqueados').textContent = bloqueados.size;
            } catch (error) {
                console.error('Erro no dashboard:', error);
            }
        }

        // ============================================
        // EMPRÉSTIMOS
        // ============================================
        async function carregarEmprestimos() {
            const container = document.getElementById('listaEmprestimos');
            await carregarSolicitacoesEmprestimo();
            try {
                // Sem orderBy no servidor: where+orderBy em campos diferentes exige índice composto
                // (sem ele a lista inteira falhava com "Erro ao carregar"). Ordena aqui.
                const snapshot = await db.collection('emprestimos')
                    .where('status','==','ativo')
                    .get();
                
                if (snapshot.empty) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-hand-holding-heart"></i><h3>Nenhum empréstimo ativo</h3></div>`;
                    return;
                }

                const dataMs = (t) => !t ? 0 : (t.toDate ? t.toDate() : new Date(t)).getTime() || 0;
                const docs = snapshot.docs.slice().sort((a, b) => dataMs(b.data().data_emprestimo) - dataMs(a.data().data_emprestimo));

                // Busca cada aluno uma única vez, em paralelo
                const ids = [...new Set(docs.map(d => d.data().aluno_id).filter(Boolean))];
                const alunosMap = {};
                await Promise.all(ids.map(async (id) => {
                    const a = await db.collection('alunos').doc(id).get();
                    if (a.exists) alunosMap[id] = a.data();
                }));
                
                let html = '';
                for (const doc of docs) {
                    const emp = { id: doc.id, ...doc.data() };
                    const aluno = alunosMap[emp.aluno_id] || null;
                    
                    const atrasado = isAtrasado(emp.data_devolucao_prevista);
                    html += `
                        <div class="emprestimo-card ${atrasado ? 'atrasado' : ''}" data-atrasado="${atrasado ? '1' : '0'}">
                            <div class="emprestimo-info">
                                <div class="emprestimo-livro">
                                    <h4>📖 ${emp.titulo_livro}</h4>
                                    <p><strong>Aluno:</strong> ${aluno?.nome || 'Removido'}</p>
                                    <p><strong>Matrícula:</strong> ${aluno?.matricula || 'N/A'}</p>
                                    <p><strong>Série/Turma:</strong> ${aluno?.serie || ''} ${aluno?.turma || ''}</p>
                                </div>
                                <div class="emprestimo-datas">
                                    <p><i class="fas fa-calendar-plus"></i> ${formatarData(emp.data_emprestimo)}</p>
                                    <p><i class="fas fa-calendar-check"></i> ${formatarData(emp.data_devolucao_prevista)}</p>
                                    ${atrasado ? `<span class="badge atrasado"><i class="fas fa-exclamation-circle"></i> ATRASADO há ${diasAtraso(emp.data_devolucao_prevista)} dia(s)</span>` : 
                                    `<span class="badge em-dia"><i class="fas fa-check-circle"></i> Em dia</span>`}
                                </div>
                                <div class="emprestimo-actions">
                                    <button class="btn-small btn-success" onclick="devolverEmprestimo('${emp.id}')"><i class="fas fa-undo"></i> Devolver</button>
                                    <button class="btn-small btn-warning" onclick="renovarEmprestimo('${emp.id}')"><i class="fas fa-sync"></i> Renovar</button>
                                    <button class="btn-small btn-danger" onclick="bloquearAluno('${emp.aluno_id}')"><i class="fas fa-ban"></i> Bloquear</button>
                                </div>
                            </div>
                        </div>
                    `;
                }
                container.innerHTML = html;
                aplicarFiltroEmprestimos();
            } catch (error) {
                console.error('Erro:', error);
                container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3></div>`;
            }
        }

        async function carregarSolicitacoesEmprestimo() {
            const container = document.getElementById('listaSolicitacoesEmprestimo');
            if (!container) return;
            try {
                const rows = await solicitacoesEmprestimoSystem.listarPendentes();
                if (!rows.length) {
                    container.innerHTML = '<p>Nenhuma solicitação pendente.</p>';
                    return;
                }
                rows.sort((a, b) => (a.data_solicitacao?.toMillis?.() || 0) - (b.data_solicitacao?.toMillis?.() || 0));
                const enriched = await Promise.all(rows.map(async row => {
                    const student = await db.collection('alunos').doc(row.aluno_id).get();
                    return { ...row, aluno: student.exists ? student.data() : null };
                }));
                container.innerHTML = enriched.map(row => `
                    <article class="emprestimo-card" style="margin:10px 0;padding:14px;border:1px solid #e2e8f0;border-radius:8px;">
                        <strong>${escapeHtml(row.titulo_livro || 'Livro')}</strong>
                        <span> — ${escapeHtml(row.aluno?.nome || row.aluno_id)} (${escapeHtml(row.aluno?.matricula || 'sem matrícula')}) · ${formatarData(row.data_solicitacao)}</span>
                        <div style="display:flex;gap:8px;margin-top:10px;">
                            <button class="btn-small btn-success" onclick="aprovarSolicitacaoEmprestimo('${escapeHtml(row.id)}')">Aprovar e registrar empréstimo</button>
                            <button class="btn-small btn-danger" onclick="recusarSolicitacaoEmprestimo('${escapeHtml(row.id)}')">Recusar</button>
                        </div>
                    </article>`).join('');
            } catch (error) {
                console.error('Solicitações não carregaram:', error);
                container.innerHTML = '<p>Não foi possível carregar as solicitações.</p>';
            }
        }

        async function aprovarSolicitacaoEmprestimo(id) {
            const result = await solicitacoesEmprestimoSystem.aprovar(id);
            showToast(result.success ? `Empréstimo registrado. Devolução até ${formatarData(result.dataDevolucao)}.` : result.error, result.success ? 'success' : 'error');
            if (result.success) {
                carregarEmprestimos();
                carregarDashboard();
                carregarAlunos();
            }
        }

        async function recusarSolicitacaoEmprestimo(id) {
            if (!confirm('Recusar esta solicitação?')) return;
            const result = await solicitacoesEmprestimoSystem.recusar(id);
            showToast(result.success ? 'Solicitação recusada.' : result.error, result.success ? 'success' : 'error');
            if (result.success) carregarSolicitacoesEmprestimo();
        }

        // ============================================
        // ALUNOS
        // ============================================
        let alunosCache = {};
        let livrosAdminCache = {};

        async function carregarAlunos() {
            const container = document.getElementById('listaAlunos');
            try {
                const snapshot = await db.collection('alunos').get();
                if (snapshot.empty) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-users"></i><h3>Nenhum aluno cadastrado</h3></div>`;
                    return;
                }
                
                const listaAlunos = snapshot.docs
                    .map(doc => ({ id: doc.id, ...doc.data() }))
                    .sort((a, b) => (a.nome || '').localeCompare(b.nome || '', 'pt-BR', { sensitivity: 'base' }));

                alunosCache = Object.fromEntries(listaAlunos.map(a => [a.id, a]));
                let html = '';
                listaAlunos.forEach(aluno => {
                    html += `
                        <div class="aluno-card">
                            <div class="aluno-avatar"><i class="fas fa-user-graduate"></i></div>
                            <div class="aluno-info">
                                <h4>${aluno.nome}</h4>
                                <p>📋 ${aluno.matricula} • ${aluno.serie} - ${aluno.turma}</p>
                                <p>📚 ${aluno.livros_atuais?.length || 0} livros emprestados</p>
                                ${aluno.bloqueado ? `<span class="badge atrasado">🔒 Bloqueado: ${aluno.motivo_bloqueio || 'Sem motivo'}</span>` : ''}
                            </div>
                            <div class="aluno-actions">
                                <button class="btn-small btn-primary" onclick="abrirEditarAluno('${aluno.id}')"><i class="fas fa-pen"></i> Editar</button>
                                ${!aluno.bloqueado ? `<button class="btn-small btn-danger" onclick="bloquearAluno('${aluno.id}')"><i class="fas fa-ban"></i> Bloquear</button>` :
                                `<button class="btn-small btn-success" onclick="desbloquearAluno('${aluno.id}')"><i class="fas fa-unlock"></i> Desbloquear</button>`}
                            </div>
                        </div>
                    `;
                });
                container.innerHTML = html;
            } catch (error) {
                container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3></div>`;
            }
        }

        // ============================================
        // LIVROS (ADMIN)
        // ============================================
        async function carregarLivrosAdmin() {
            const container = document.getElementById('listaLivrosAdmin');
            try {
                const livros = await livrosSystem.listarLivros();
                livrosAdminCache = Object.fromEntries(livros.map(l => [l.id, l]));
                const reservasAtivas = await reservasSystem.listarAtivas().catch(() => []);
                if (livros.length === 0) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-book"></i><h3>Nenhum livro cadastrado</h3></div>`;
                    return;
                }

                container.innerHTML = livros.map(livro => `
                    <div class="livro-admin-card">
                        <div class="livro-admin-capa">
                            <img src="${escapeHtml(urlCapaLivro(livro))}" data-titulo="${escapeHtml(livro.titulo)}" data-autor="${escapeHtml(livro.autor)}" alt="${escapeHtml(livro.titulo)}" onerror="this.onerror=null;this.src='assets/images/default-cover.png';window.completarCapaLivro(this)">
                        </div>
                        <div class="livro-admin-info">
                            <h4>${escapeHtml(livro.titulo)}</h4>
                            <p>${escapeHtml(livro.autor)}</p>
                            <p><span class="livro-genero">${escapeHtml(livro.genero)}</span></p>
                            <p>📚 ${livro.quantidade_disponivel}/${livro.quantidade_total} disponíveis</p>
                            <p>📊 ${livro.total_emprestimos || 0} empréstimos</p>
                            ${reservasSystem.fila(livro.id, reservasAtivas).length ? `<p>📌 ${reservasSystem.fila(livro.id, reservasAtivas).length} reserva(s) na fila</p>` : ''}
                        </div>
                        <div class="livro-admin-actions">
                            <button class="btn-small btn-primary" onclick="abrirEditarLivro('${escapeHtml(livro.id)}')"><i class="fas fa-pen"></i> Editar</button>
                            ${reservasSystem.fila(livro.id, reservasAtivas).length ? `<button class="btn-small btn-warning" onclick="verReservas('${escapeHtml(livro.id)}')"><i class="fas fa-clock"></i> Reservas</button>` : ''}
                            <button class="btn-small btn-danger" onclick="removerLivro('${escapeHtml(livro.id)}')"><i class="fas fa-trash"></i> Remover</button>
                        </div>
                    </div>
                `).join('');
            } catch (error) {
                console.error('Erro ao carregar livros:', error);
                container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3><p>${escapeHtml(error.message || '')}</p></div>`;
            }
        }

        // ============================================
        // AÇÕES ADMIN
        // ============================================
        async function devolverEmprestimo(emprestimoId) {
            if (!confirm('Confirmar devolução deste livro?')) return;
            try {
                const empDoc = await db.collection('emprestimos').doc(emprestimoId).get();
                const emp = empDoc.data();
                const result = await livrosSystem.devolverLivro(emp.livro_id, emp.aluno_id);
                if (result.success) {
                    showToast('✅ Livro devolvido com sucesso!', 'success');
                    (result.novasConquistas || []).forEach(b => showToast(`🎉 O aluno conquistou: ${b.icone} ${b.nome}`, 'success'));
                    carregarEmprestimos();
                    carregarDashboard();
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                console.error(error);
                showToast('❌ Erro ao devolver', 'error');
            }
        }

        async function renovarEmprestimo(emprestimoId) {
            if (!confirm('Renovar empréstimo por mais 7 dias?')) return;
            try {
                // Mesma regra do sistema: só uma renovação por empréstimo
                const result = await emprestimosSystem.renovarEmprestimo(emprestimoId, { admin: true });
                if (result.success) {
                    showToast('✅ Renovado até ' + formatarData(result.novaDataDevolucao), 'success');
                    carregarEmprestimos();
                    carregarDashboard();
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showToast('❌ Erro ao renovar', 'error');
            }
        }

        async function bloquearAluno(alunoId) {
            const motivo = prompt('Motivo do bloqueio:');
            if (!motivo) return;
            try {
                await db.collection('alunos').doc(alunoId).update({
                    bloqueado: true,
                    motivo_bloqueio: motivo
                });
                showToast('🔒 Aluno bloqueado!', 'warning');
                carregarEmprestimos();
                carregarAlunos();
                carregarDashboard();
            } catch (error) {
                showToast('❌ Erro ao bloquear', 'error');
            }
        }

        async function desbloquearAluno(alunoId) {
            if (!confirm('Desbloquear este aluno?')) return;
            try {
                await db.collection('alunos').doc(alunoId).update({
                    bloqueado: false,
                    motivo_bloqueio: null
                });
                showToast('✅ Aluno desbloqueado!', 'success');
                carregarAlunos();
                carregarDashboard();
            } catch (error) {
                showToast('❌ Erro ao desbloquear', 'error');
            }
        }

        async function removerLivro(livroId) {
            if (!confirm('Remover este livro? (Só pode ser removido se não estiver emprestado)')) return;
            try {
                const result = await livrosSystem.removerLivro(livroId);
                if (result.success) {
                    showToast('✅ Livro removido!', 'success');
                    carregarLivrosAdmin();
                    carregarDashboard();
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showToast('❌ Erro ao remover', 'error');
            }
        }

        function adicionarLivro() {
            document.getElementById('modalAdicionarLivro').classList.add('active');
            const endpoint = document.getElementById('endpointCapaIa');
            if (endpoint) endpoint.value = localStorage.getItem('bibliotecaCapaIaEndpoint') || '';
        }

        // ============================================
        // SALVAR LIVRO (CORRIGIDO!)
        // ============================================
        async function salvarLivro(event) {
            event.preventDefault();
            
            const dados = {
                titulo: document.getElementById('livroTitulo').value.trim(),
                autor: document.getElementById('livroAutor').value.trim(),
                genero: document.getElementById('livroGenero').value,
                quantidade: parseInt(document.getElementById('livroQuantidade').value) || 1
            };
            
            if (!dados.titulo || !dados.autor || !dados.genero) {
                showToast('❌ Preencha todos os campos!', 'error');
                return;
            }
            
            const btn = event.target.querySelector('button[type="submit"]');
            btn.disabled = true;
            localStorage.setItem('bibliotecaCapaIaEndpoint', document.getElementById('endpointCapaIa')?.value.trim() || '');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Localizando ou gerando capa...';
            
            try {
                // Mesmo caminho de cadastro usado em todo o sistema
                const result = await livrosSystem.adicionarLivro(dados);
                if (!result.success) {
                    showToast('❌ ' + result.error, 'error');
                    return;
                }

                showToast('✅ Livro adicionado com sucesso!', 'success');
                fecharModal('modalAdicionarLivro');
                document.getElementById('formAdicionarLivro').reset();
                carregarLivrosAdmin();
                carregarDashboard();
                
            } catch (error) {
                console.error('Erro:', error);
                showToast('❌ Erro: ' + error.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Salvar Livro';
            }
        }

        // ============================================
        // EDITAR ALUNO
        // ============================================
        function copiarOpcoes(destinoId, origemId, valor) {
            const sel = document.getElementById(destinoId);
            if (!sel.options.length) sel.innerHTML = document.getElementById(origemId).innerHTML;
            if (valor && ![...sel.options].some(o => o.value === valor)) sel.add(new Option(valor, valor));
            sel.value = valor || '';
        }

        function abrirEditarAluno(id) {
            const a = alunosCache[id];
            if (!a) return;
            document.getElementById('editAlunoId').value = id;
            document.getElementById('editAlunoNome').value = a.nome || '';
            document.getElementById('editAlunoMatricula').value = a.matricula || '';
            copiarOpcoes('editAlunoSerie', 'alunoSerie', a.serie);
            copiarOpcoes('editAlunoTurma', 'alunoTurma', a.turma);
            document.getElementById('modalEditarAluno').classList.add('active');
        }

        async function salvarEdicaoAluno(event) {
            event.preventDefault();
            const id = document.getElementById('editAlunoId').value;
            const dados = {
                nome: document.getElementById('editAlunoNome').value.trim(),
                serie: document.getElementById('editAlunoSerie').value,
                turma: document.getElementById('editAlunoTurma').value
            };
            if (!dados.nome || !dados.serie || !dados.turma) { showToast('❌ Preencha todos os campos!', 'error'); return; }

            const btn = event.target.querySelector('button[type="submit"]');
            btn.disabled = true;
            try {
                await db.collection('alunos').doc(id).update(dados);
                showToast('✅ Aluno atualizado!', 'success');
                fecharModal('modalEditarAluno');
                carregarAlunos();
                carregarEmprestimos();
            } catch (error) {
                console.error(error);
                showToast('❌ Erro ao salvar: ' + error.message, 'error');
            } finally {
                btn.disabled = false;
            }
        }

        // ============================================
        // EDITAR LIVRO (a quantidade respeita os exemplares emprestados)
        // ============================================
        function abrirEditarLivro(id) {
            const l = livrosAdminCache[id];
            if (!l) return;
            const emprestados = l.quantidade_total - l.quantidade_disponivel;
            document.getElementById('editLivroId').value = id;
            document.getElementById('editLivroTitulo').value = l.titulo;
            document.getElementById('editLivroAutor').value = l.autor;
            copiarOpcoes('editLivroGenero', 'livroGenero', l.genero);
            const q = document.getElementById('editLivroQuantidade');
            q.value = l.quantidade_total;
            q.min = Math.max(1, emprestados);
            document.getElementById('editLivroDica').textContent = emprestados > 0
                ? `${emprestados} exemplar(es) emprestado(s): a quantidade não pode ser menor que isso.` : '';
            document.getElementById('editLivroCapa').checked = false;
            document.getElementById('modalEditarLivro').classList.add('active');
        }

        async function salvarEdicaoLivro(event) {
            event.preventDefault();
            const id = document.getElementById('editLivroId').value;
            const atual = livrosAdminCache[id];
            const dados = {
                titulo: document.getElementById('editLivroTitulo').value.trim(),
                autor: document.getElementById('editLivroAutor').value.trim(),
                genero: document.getElementById('editLivroGenero').value,
                total: parseInt(document.getElementById('editLivroQuantidade').value, 10)
            };
            if (!dados.titulo || !dados.autor || !dados.genero || !(dados.total >= 1)) {
                showToast('❌ Preencha todos os campos corretamente!', 'error');
                return;
            }

            const btn = event.target.querySelector('button[type="submit"]');
            btn.disabled = true;
            try {
                // Capa: busca de novo se pedido ou se título/autor mudaram (se não achar, mantém a atual)
                let capaUrl = atual ? atual.capaUrl : null;
                const mudou = atual && (dados.titulo !== atual.titulo || dados.autor !== atual.autor);
                if (document.getElementById('editLivroCapa').checked || mudou) {
                    try {
                        const c = await googleBooksService.buscarCapa(dados.titulo, dados.autor, dados.genero);
                        if (c && !c.includes('default-cover')) capaUrl = c;
                    } catch (_) {}
                }

                const ref = db.collection('livros').doc(id);
                await db.runTransaction(async (t) => {
                    const doc = await t.get(ref);
                    if (!doc.exists) throw new Error('Livro não encontrado');
                    const n = normalizarLivro(id, doc.data());
                    const emprestados = n.quantidade_total - n.quantidade_disponivel;
                    if (dados.total < emprestados) {
                        throw new Error(`Há ${emprestados} exemplar(es) emprestado(s). A quantidade mínima é ${emprestados}.`);
                    }
                    t.update(ref, {
                        titulo: dados.titulo,
                        autor: dados.autor,
                        genero: dados.genero,
                        titulo_busca: dados.titulo.toLowerCase(),
                        quantidade_total: dados.total,
                        quantidade_disponivel: dados.total - emprestados,
                        capaUrl: capaUrl || 'assets/images/default-cover.png'
                    });
                });

                showToast('✅ Livro atualizado!', 'success');
                fecharModal('modalEditarLivro');
                carregarLivrosAdmin();
                carregarDashboard();
            } catch (error) {
                console.error(error);
                showToast('❌ ' + error.message, 'error');
            } finally {
                btn.disabled = false;
            }
        }

        // ============================================
        // RESERVAS DE UM LIVRO
        // ============================================
        async function verReservas(livroId) {
            const livro = livrosAdminCache[livroId];
            document.getElementById('reservasTitulo').textContent = 'Reservas: ' + (livro ? livro.titulo : '');
            const lista = document.getElementById('reservasLista');
            lista.innerHTML = '<p>Carregando...</p>';
            document.getElementById('modalReservas').classList.add('active');
            try {
                const fila = reservasSystem.fila(livroId, await reservasSystem.listarAtivas());
                if (fila.length === 0) { lista.innerHTML = '<p>Nenhuma reserva ativa.</p>'; return; }
                lista.innerHTML = fila.map((r, i) => `
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #eee;">
                        <span><strong>${i + 1}º</strong> ${escapeHtml(r.aluno_nome || 'Aluno')} <small>(reservou em ${formatarData(r.data_reserva)})</small></span>
                        <button class="btn-small btn-danger" onclick="cancelarReservaAdmin('${escapeHtml(r.id)}', '${escapeHtml(livroId)}')"><i class="fas fa-times"></i> Cancelar</button>
                    </div>`).join('');
            } catch (error) {
                lista.innerHTML = '<p>Erro ao carregar as reservas.</p>';
            }
        }

        async function cancelarReservaAdmin(reservaId, livroId) {
            if (!confirm('Cancelar esta reserva?')) return;
            const r = await reservasSystem.cancelarPorId(reservaId);
            showToast(r.success ? '✅ Reserva cancelada' : '❌ ' + r.error, r.success ? 'success' : 'error');
            verReservas(livroId);
            carregarLivrosAdmin();
        }

        function adicionarAluno() {
            document.getElementById('modalAdicionarAluno').classList.add('active');
        }

        // ============================================
        // SALVAR ALUNO (CORRIGIDO!)
        // ============================================
        async function salvarAluno(event) {
            event.preventDefault();
            
            const dados = {
                nome: document.getElementById('alunoNome').value.trim(),
                matricula: document.getElementById('alunoMatricula').value.trim(),
                serie: document.getElementById('alunoSerie').value,
                turma: document.getElementById('alunoTurma').value,
                senha: 'escola2026',
                confirmarSenha: 'escola2026',
                senhaPadrao: true      // o aluno verá um aviso para trocar a senha
            };
            
            if (!dados.nome || !dados.matricula || !dados.serie || !dados.turma) {
                showToast('❌ Preencha todos os campos!', 'error');
                return;
            }
            
            const btn = event.target.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cadastrando...';
            
            try {
                const result = await authSystem.cadastrarAluno(dados);
                if (result.success) {
                    showToast('✅ Aluno cadastrado! Senha padrão: escola2026', 'success');
                    fecharModal('modalAdicionarAluno');
                    document.getElementById('formAdicionarAluno').reset();
                    carregarAlunos();
                    carregarDashboard();
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showToast('❌ Erro: ' + error.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Cadastrar Aluno';
            }
        }

        // ============================================
        // EVENT LISTENERS
        // ============================================
        function setupEventListeners() {
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (!btn.dataset.tab) return; // aba-link (Área do Aluno) não troca de painel
                    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
                    if (btn.dataset.tab === 'alunos') carregarAlunos();
                    if (btn.dataset.tab === 'livros') carregarLivrosAdmin();
                });
            });
            
            document.getElementById('tabAreaAluno').addEventListener('click', () => {
                window.location.href = 'index.html?modo=admin';
            });

            document.getElementById('btnLogoutAdmin').addEventListener('click', async () => {
                if (confirm('Deseja sair?')) {
                    await authSystem.logout();
                    window.location.href = 'login.html';
                }
            });
            
            document.getElementById('searchEmprestimos')?.addEventListener('input', aplicarFiltroEmprestimos);
            document.getElementById('filtroAtrasados')?.addEventListener('change', aplicarFiltroEmprestimos);

            const filtrarCards = (inputId, seletor) => {
                document.getElementById(inputId)?.addEventListener('input', (e) => {
                    const termo = e.target.value.toLowerCase();
                    document.querySelectorAll(seletor).forEach(card => {
                        card.style.display = card.textContent.toLowerCase().includes(termo) ? '' : 'none';
                    });
                });
            };
            filtrarCards('searchAlunos', '.aluno-card');
            filtrarCards('searchLivrosAdmin', '.livro-admin-card');
        }

        // ============================================
        // EXPORTAR FUNÇÕES GLOBAIS
        // ============================================
        window.devolverEmprestimo = devolverEmprestimo;
        window.aprovarSolicitacaoEmprestimo = aprovarSolicitacaoEmprestimo;
        window.recusarSolicitacaoEmprestimo = recusarSolicitacaoEmprestimo;
        window.renovarEmprestimo = renovarEmprestimo;
        window.bloquearAluno = bloquearAluno;
        window.desbloquearAluno = desbloquearAluno;
        window.removerLivro = removerLivro;
        window.adicionarLivro = adicionarLivro;
        window.salvarLivro = salvarLivro;
        window.adicionarAluno = adicionarAluno;
        window.salvarAluno = salvarAluno;
        window.fecharModal = fecharModal;
        window.abrirEditarAluno = abrirEditarAluno;
        window.salvarEdicaoAluno = salvarEdicaoAluno;
        window.abrirEditarLivro = abrirEditarLivro;
        window.salvarEdicaoLivro = salvarEdicaoLivro;
        window.verReservas = verReservas;
        window.cancelarReservaAdmin = cancelarReservaAdmin;
