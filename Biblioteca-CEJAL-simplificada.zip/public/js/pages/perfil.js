let userData = null;
        let allLivros = [];

        document.addEventListener('DOMContentLoaded', async () => {
            userData = await authGuard.requireAluno();
            if (!userData) return; // já redirecionou
            carregarPerfil();
            await carregarLivros();
            if (window.location.hash === '#historico') {
                document.getElementById('historicoContainer')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });

        function carregarPerfil() {
            document.getElementById('perfilNome').textContent = userData.nome;
            document.getElementById('perfilMatricula').textContent = '📋 ' + userData.matricula;
            document.getElementById('perfilSerieTurma').textContent = userData.serie + ' - Turma ' + userData.turma;
            
            document.getElementById('totalLidos').textContent = userData.total_lidos || 0;
            document.getElementById('livrosAtuais').textContent = userData.livros_atuais?.length || 0;
            
            const dataCadastro = userData.data_cadastro?.toDate() || new Date();
            const dias = Math.floor((new Date() - dataCadastro) / (1000 * 60 * 60 * 24));
            document.getElementById('diasLeitor').textContent = dias || 0;
            
            document.getElementById('avisoSenhaPadrao').style.display = userData.senha_padrao ? 'block' : 'none';
            carregarConquistas();
        }

        // ---------------- CONQUISTAS ----------------
        async function carregarConquistas() {
            const box = document.getElementById('badgesContainer');
            try {
                const { novas, todas } = await conquistasSystem.verificar(userData.id);
                novas.forEach(b => showToast(`🎉 Nova conquista: ${b.icone} ${b.nome}!`, 'success', 7000));

                const ganhas = todas.filter(b => b.ok);
                const faltam = todas.filter(b => !b.ok);
                const chip = (b, bloqueada) => `<span class="badge-item" title="${escapeHtml(b.descricao)}" style="${bloqueada ? 'opacity:.55;' : ''}">${bloqueada ? '🔒' : b.icone} ${escapeHtml(b.nome)}${bloqueada ? ` (${b.progresso}/${b.total})` : ''}</span>`;

                box.innerHTML =
                    (ganhas.length
                        ? ganhas.map(b => chip(b, false)).join('')
                        : '<p style="color:var(--text-secondary);font-size:var(--font-size-sm);">Nenhuma conquista ainda. Continue lendo!</p>') +
                    (faltam.length
                        ? '<p style="margin:14px 0 6px;color:var(--text-secondary);font-size:var(--font-size-sm);">Próximas conquistas:</p>' + faltam.map(b => chip(b, true)).join('')
                        : '');
            } catch (error) {
                console.error('Erro nas conquistas:', error);
                box.innerHTML = '<p style="color:var(--text-secondary);font-size:var(--font-size-sm);">Não foi possível carregar as conquistas agora.</p>';
            }
        }

        // ---------------- LIVROS ATUAIS + HISTÓRICO + RESERVAS ----------------
        const vazio = (txt) => `<p style="color:var(--text-secondary);font-size:var(--font-size-sm);">${txt}</p>`;
        const toDate = (t) => { if (!t) return null; const d = t.toDate ? t.toDate() : new Date(t); return isNaN(d.getTime()) ? null : d; };

        function miniLivro(livro, linhaExtra) {
            return `
                <div class="livro-mini">
                    <img src="${escapeHtml(urlCapaLivro(livro))}" data-titulo="${escapeHtml(livro.titulo)}" data-autor="${escapeHtml(livro.autor)}" alt="${escapeHtml(livro.titulo)}" onerror="this.onerror=null;this.src='assets/images/default-cover.png';window.completarCapaLivro(this)">
                    <div class="livro-mini-info">
                        <h4>${escapeHtml(livro.titulo)}</h4>
                        <p>${escapeHtml(livro.autor)} • ${escapeHtml(livro.genero)}</p>
                        ${linhaExtra ? `<p>${linhaExtra}</p>` : ''}
                    </div>
                </div>`;
        }

        async function carregarLivros() {
            const [livrosSnap, empSnap] = await Promise.all([
                db.collection('livros').get(),
                db.collection('emprestimos').where('aluno_id', '==', userData.id).get()   // 1 campo: sem índice
            ]);

            allLivros = [];
            livrosSnap.forEach(doc => allLivros.push(normalizarLivro(doc.id, doc.data())));
            const porId = Object.fromEntries(allLivros.map(l => [l.id, l]));

            const emprestimos = empSnap.docs.map(d => ({ id: d.id, ...d.data() }))
                .sort((a, b) => (toDate(b.data_emprestimo)?.getTime() || 0) - (toDate(a.data_emprestimo)?.getTime() || 0));
            const ativos = emprestimos.filter(e => e.status === 'ativo');
            const devolvidos = emprestimos.filter(e => e.status === 'devolvido');
            const agora = new Date();

            // ----- Livros emprestados agora (com data de devolução) -----
            const atuaisContainer = document.getElementById('livrosAtuaisContainer');
            const idsComEmprestimo = new Set(ativos.map(e => e.livro_id));
            const semRegistro = (userData.livros_atuais || []).filter(id => !idsComEmprestimo.has(id) && porId[id]);
            if (ativos.length === 0 && semRegistro.length === 0) {
                atuaisContainer.innerHTML = vazio('Nenhum livro emprestado');
            } else {
                atuaisContainer.innerHTML =
                    ativos.map(e => {
                        const livro = porId[e.livro_id] || normalizarLivro(e.livro_id, { titulo: e.titulo_livro });
                        const prev = toDate(e.data_devolucao_prevista);
                        const atrasado = prev && prev < agora;
                        return miniLivro(livro, prev ? `${atrasado ? '⚠️ <strong>Atrasado</strong> desde' : '⏰ Devolver até'} <strong>${formatarData(prev)}</strong>` : '');
                    }).join('') +
                    semRegistro.map(id => miniLivro(porId[id], '')).join('');
            }

            // ----- Histórico: um item por empréstimo devolvido (repetições aparecem) -----
            const historicoContainer = document.getElementById('historicoContainer');
            if (devolvidos.length > 0) {
                historicoContainer.innerHTML = devolvidos.map(e => {
                    const livro = porId[e.livro_id] || normalizarLivro(e.livro_id, { titulo: e.titulo_livro });
                    const prev = toDate(e.data_devolucao_prevista), real = toDate(e.data_devolucao_real);
                    const noPrazo = prev && real ? real <= prev : null;
                    const selo = noPrazo === null ? '' : (noPrazo ? ' • ✅ No prazo' : ' • ⚠️ Com atraso');
                    return miniLivro(livro, `📅 ${formatarData(e.data_emprestimo)} → ${real ? formatarData(real) : '—'}${selo}`);
                }).join('');
            } else if ((userData.historico || []).length > 0) {
                // Alunos antigos: só existe a lista de IDs
                const unicos = [...new Set(userData.historico)].filter(id => porId[id]);
                historicoContainer.innerHTML = unicos.length ? unicos.map(id => miniLivro(porId[id], '')).join('') : vazio('Nenhum livro lido ainda');
            } else {
                historicoContainer.innerHTML = vazio('Nenhum livro lido ainda');
            }

            carregarReservas(porId);
        }

        async function carregarReservas(porId) {
            const box = document.getElementById('reservasContainer');
            try {
                const minhas = await reservasSystem.listarMinhasAtivas(userData.id);
                if (minhas.length === 0) { box.innerHTML = vazio('Nenhuma reserva ativa'); return; }

                box.innerHTML = minhas.map(r => {
                    const livro = (porId && porId[r.livro_id]) || normalizarLivro(r.livro_id, { titulo: r.titulo_livro });
                    return `
                        <div class="livro-mini">
                            <img src="${escapeHtml(urlCapaLivro(livro))}" data-titulo="${escapeHtml(livro.titulo)}" data-autor="${escapeHtml(livro.autor)}" alt="${escapeHtml(livro.titulo)}" onerror="this.onerror=null;this.src='assets/images/default-cover.png';window.completarCapaLivro(this)">
                            <div class="livro-mini-info">
                                <h4>${escapeHtml(livro.titulo)}</h4>
                                <p>📌 Reserva enviada. Aguarde o atendimento do administrador.</p>
                                <p><a href="#" onclick="cancelarReservaPerfil('${escapeHtml(r.livro_id)}');return false;">Cancelar reserva</a></p>
                            </div>
                        </div>`;
                }).join('');
            } catch (error) {
                console.error(error);
                box.innerHTML = vazio('Não foi possível carregar as reservas agora.');
            }
        }

        async function cancelarReservaPerfil(livroId) {
            const r = await reservasSystem.cancelar(livroId, userData.id);
            showToast(r.success ? '✅ Reserva cancelada' : '❌ ' + r.error, r.success ? 'success' : 'error');
            carregarReservas(Object.fromEntries(allLivros.map(l => [l.id, l])));
        }

        // ---------------- ALTERAR SENHA ----------------
        async function trocarSenha(event) {
            event.preventDefault();
            const atual = document.getElementById('senhaAtual').value;
            const nova = document.getElementById('senhaNova').value;
            const confirma = document.getElementById('senhaConfirma').value;
            if (nova !== confirma) { showToast('❌ As senhas novas não coincidem', 'error'); return; }

            const btn = event.target.querySelector('button[type="submit"]');
            btn.disabled = true;
            const r = await authSystem.alterarSenha(atual, nova);
            btn.disabled = false;

            if (r.success) {
                showToast('✅ Senha alterada com sucesso!', 'success');
                event.target.reset();
                userData.senha_padrao = false;
                document.getElementById('avisoSenhaPadrao').style.display = 'none';
                try { sessionStorage.removeItem('cejal_aviso_senha'); } catch (_) {}
            } else {
                showToast('❌ ' + r.error, 'error');
            }
        }

        async function sair() {
            if (confirm('Deseja realmente sair?')) {
                await authSystem.logout();
                window.location.href = 'login.html';
            }
        }
