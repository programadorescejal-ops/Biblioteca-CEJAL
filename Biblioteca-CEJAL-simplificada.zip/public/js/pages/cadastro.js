async function fazerCadastro(event) {
            event.preventDefault();
            
            const dados = {
                nome: document.getElementById('nome').value.trim(),
                matricula: document.getElementById('matricula').value.trim(),
                serie: document.getElementById('serie').value,
                turma: document.getElementById('turma').value,
                senha: document.getElementById('senha').value,
                confirmarSenha: document.getElementById('confirmarSenha').value
            };
            
            if (!dados.nome || !dados.matricula || !dados.serie || !dados.turma) {
                showToast('Preencha todos os campos', 'error');
                return;
            }
            
            if (dados.senha !== dados.confirmarSenha) {
                showToast('As senhas não coincidem', 'error');
                return;
            }
            
            if (dados.senha.length < 6) {
                showToast('A senha deve ter no mínimo 6 caracteres', 'error');
                return;
            }
            
            const loading = showLoading('Cadastrando...');
            try {
                const result = await authSystem.cadastrarAluno(dados);
                loading.close();
                
                if (result.success) {
                    showToast('✅ Cadastro realizado com sucesso!', 'success');
                    setTimeout(() => window.location.href = 'login.html', 2000);
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                loading.close();
                showToast('❌ Erro ao cadastrar: ' + error.message, 'error');
            }
        }
