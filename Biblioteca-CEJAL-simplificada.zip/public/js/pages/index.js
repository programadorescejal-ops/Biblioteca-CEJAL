let currentFilter = 'todos';
        let searchTerm = '';
        let userData = null;
        let livrosCarregados = false;
        let meusEmprestimos = {};   // livro_id -> data_devolucao_prevista
        let minhasSolicitacoes = {};

        document.addEventListener('DOMContentLoaded', async () => {
            try {
                // Uma única verificação: login + papel + perfil do aluno
                userData = await authGuard.requireAluno({ permitirAdmin: true });
                if (!userData) return; // já redirecionou

                updateUserUI(userData);
                if (userData.modoAdmin) aplicarModoAdmin();
                await carregarMeusEmprestimos();
                const aoMudarReservas = () => {
                    if (livrosCarregados) void atualizarCatalogo(livrosSystem.livros);
                };
                if (userData.modoAdmin) reservasSystem.observarAtivas(aoMudarReservas);
                else reservasSystem.observarMinhasAtivas(userData.id, aoMudarReservas);
                if (!userData.modoAdmin) {
                    solicitacoesEmprestimoSystem.observarMinhas(userData.id, rows => {
                        minhasSolicitacoes = Object.fromEntries(rows.filter(r => r.status === 'pendente').map(r => [r.livro_id, r.id]));
                        if (livrosCarregados) renderLivros(livrosSystem.livros);
                    }, error => console.warn('Solicitações indisponíveis:', error.code || error.message));
                    emprestimosSystem.listarEmprestimosEmTempoReal(userData.id, rows => {
                        const ativos = rows.filter(r => r.status === 'ativo');
                        meusEmprestimos = Object.fromEntries(ativos.map(r => [r.livro_id, r.data_devolucao_prevista]));
                        userData.livros_atuais = ativos.map(r => r.livro_id);
                        if (livrosCarregados) {
                            renderLivros(livrosSystem.livros);
                            updateStats(livrosSystem.livros);
                        }
                    });
                }
                initLivros();
                avisarSenhaPadrao();
                setupEventListeners();
                if (!userData.modoAdmin) checkAtrasos();
            } catch (err) {
                console.error('Falha ao iniciar catálogo:', err);
                showToast('Erro ao carregar o catálogo. Recarregue a página.', 'error');
            }
        });

        async function carregarMeusEmprestimos() {
            meusEmprestimos = {};
            if (!userData || userData.modoAdmin) return;
            try {
                const ativos = await emprestimosSystem.listarEmprestimosAtivos(userData.id);
                ativos.forEach(e => { meusEmprestimos[e.livro_id] = e.data_devolucao_prevista; });
                const solicitacoes = await solicitacoesEmprestimoSystem.listarMinhas();
                solicitacoes.filter(s => s.status === 'pendente').forEach(s => { minhasSolicitacoes[s.livro_id] = s.id; });
            } catch (e) {
                console.warn('Não foi possível carregar datas de devolução', e);
            }
        }

        function initLivros() {
            livrosSystem.listarLivrosEmTempoReal(null, (livros) => {
                livrosCarregados = true;
                updateStats(livros);
                void atualizarCatalogo(livros);
            }, (error) => {
                // Antes o erro só ia para o console e a tela ficava em "Carregando..." para sempre
                document.getElementById('listaLivros').innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3>Não foi possível carregar os livros</h3>
                        <p>${escapeHtml(error.code === 'permission-denied' ? 'Sem permissão para ler o catálogo.' : 'Verifique a internet e recarregue a página.')}</p>
                    </div>`;
            });
        }

        // Admin vendo a área do aluno: só visualização + atalho para voltar ao painel
        function aplicarModoAdmin() {
            const banner = document.createElement('div');
            banner.style.cssText = 'background:#1e293b;color:#fff;padding:10px 16px;display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;font-size:14px;';
            banner.innerHTML = '<span><i class="fas fa-eye"></i> Modo administrador: você está vendo o catálogo como os alunos veem.</span>' +
                '<button type="button" id="btnVoltarPainel" style="background:#fff;color:#1e293b;border:0;border-radius:6px;padding:6px 12px;cursor:pointer;font-weight:600;"><i class="fas fa-arrow-left"></i> Voltar ao painel</button>';
            document.body.insertBefore(banner, document.body.firstChild);
            document.getElementById('btnVoltarPainel').addEventListener('click', () => window.location.href = 'admin.html');

            const perfil = document.getElementById('btnProfile');
            perfil.disabled = true;
            perfil.style.cursor = 'default';
            document.getElementById('adminNav').style.display = '';
            document.querySelector('[data-filter="meus"]').style.display = 'none';
        }

        async function atualizarCatalogo(livros) {
            renderLivros(livros);
        }
        function renderLivros(livros) {
            const container = document.getElementById('listaLivros');
            let filtered = livros;
            
            if (searchTerm) {
                const term = searchTerm.toLowerCase();
                filtered = filtered.filter(l => 
                    (l.titulo || '').toLowerCase().includes(term) ||
                    (l.autor || '').toLowerCase().includes(term) ||
                    (l.genero || '').toLowerCase().includes(term)
                );
            }
            
            switch(currentFilter) {
                case 'disponiveis': filtered = filtered.filter(l => l.quantidade_disponivel > 0); break;
                case 'emprestados': filtered = filtered.filter(l => l.quantidade_disponivel < l.quantidade_total); break;
                case 'meus': filtered = filtered.filter(l => userData?.livros_atuais?.includes(l.id)); break;
            }
            
            if (filtered.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-book-open"></i>
                        <h3>Nenhum livro encontrado</h3>
                        <p>Tente ajustar sua busca ou filtros</p>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = filtered.map(livro => createLivroCard(livro)).join('');
        }

        function createLivroCard(livro) {
            const somenteVer = !!userData?.modoAdmin;
            const meuId = userData?.id;
            const temEmprestimo = !!userData?.livros_atuais?.includes(livro.id);

            const devolucaoPrevista = meusEmprestimos[livro.id];
            const dataDevolucao = devolucaoPrevista ? formatarData(devolucaoPrevista) : '';
            const atrasado = devolucaoPrevista && (devolucaoPrevista.toDate ? devolucaoPrevista.toDate() : new Date(devolucaoPrevista)) < new Date();

            // Fila de reservas
            const fila = reservasSystem.fila(livro.id);
            const solicitacaoPendente = !somenteVer && minhasSolicitacoes[livro.id];
            const reservaAtiva = !somenteVer && reservasSystem.ativas.some(r => r.livro_id === livro.id && r.aluno_id === meuId && r.status === 'ativa');
            const podePegar = !temEmprestimo && reservasSystem.podePegar(livro, meuId);
            const disponivel = livro.quantidade_disponivel > 0;

            let status = disponivel ? ['disponivel', '✅ Disponível'] : ['indisponivel', '🔴 Indisponível'];
            if (solicitacaoPendente) status = ['indisponivel', '⏳ Aguardando aprovação'];
            else if (reservaAtiva) status = ['indisponivel', '📌 Reserva enviada'];

            let acao = '';
            if (!somenteVer) {
                const id = escapeHtml(livro.id);
                if (temEmprestimo) {
                    acao = '';
                } else if (solicitacaoPendente) {
                    acao = `<button class="btn-secondary btn-reservar" onclick="cancelarSolicitacao('${escapeHtml(minhasSolicitacoes[livro.id])}')"><i class="fas fa-times"></i> Cancelar solicitação</button>`;
                } else if (reservaAtiva) {
                    acao = `<button class="btn-secondary btn-reservar" onclick="cancelarReserva('${id}')"><i class="fas fa-times"></i> Cancelar reserva</button>`;
                } else if (podePegar) {
                    acao = `<button class="btn-primary btn-pegar" onclick="pegarLivro('${id}')"><i class="fas fa-hand-holding-heart"></i> Solicitar empréstimo</button>`;
                } else {
                    acao = `<button class="btn-secondary btn-reservar" onclick="reservarLivro('${id}')"><i class="fas fa-clock"></i> Reservar</button>`;
                }
            }

            let infoFila = '';
            if (!temEmprestimo && solicitacaoPendente) infoFila = `<div class="livro-devolucao"><i class="fas fa-hourglass-half"></i> Solicitação enviada ao administrador</div>`;
            else if (!temEmprestimo && reservaAtiva) infoFila = `<div class="livro-devolucao"><i class="fas fa-hourglass-half"></i> Reserva enviada; aguarde o administrador</div>`;
            else if (!temEmprestimo && userData?.modoAdmin && fila.length > 0) infoFila = `<div class="livro-devolucao"><i class="fas fa-list-ol"></i> ${fila.length} na fila de reserva</div>`;
            
            return `
                <div class="livro-card" data-id="${escapeHtml(livro.id)}">
                    <div class="livro-capa">
                        <img src="${escapeHtml(urlCapaLivro(livro))}" data-titulo="${escapeHtml(livro.titulo)}" data-autor="${escapeHtml(livro.autor)}" alt="${escapeHtml(livro.titulo)}" loading="lazy" onerror="this.onerror=null;this.src='assets/images/default-cover.png';window.completarCapaLivro(this)">
                        <span class="livro-status ${status[0]}">${status[1]}</span>
                    </div>
                    <div class="livro-info">
                        <h3 class="livro-titulo">${escapeHtml(livro.titulo)}</h3>
                        <p class="livro-autor"><i class="fas fa-user-edit"></i> ${escapeHtml(livro.autor)}</p>
                        <div class="livro-meta">
                            <span class="livro-genero"><i class="fas fa-tag"></i> ${escapeHtml(livro.genero)}</span>
                            <span class="livro-exemplares"><i class="fas fa-copy"></i> ${livro.quantidade_disponivel}/${livro.quantidade_total}</span>
                        </div>
                        ${temEmprestimo ? `<div class="livro-devolucao"><i class="fas fa-clock"></i> ${atrasado ? '⚠️ Atrasado desde' : 'Devolver até'}: <strong>${dataDevolucao}</strong><br>Procure a biblioteca para concluir a devolução.</div>` : ''}
                        ${infoFila}
                        <div class="livro-actions">${acao}</div>
                    </div>
                </div>
            `;
        }

        // Aluno ainda com a senha padrão criada pelo bibliotecário
        function avisarSenhaPadrao() {
            if (!userData || !userData.senha_padrao) return;
            try {
                if (sessionStorage.getItem('cejal_aviso_senha')) return;
                sessionStorage.setItem('cejal_aviso_senha', '1');
            } catch (_) {}
            showToast('🔒 Você está usando a senha padrão. Troque em Perfil > Alterar senha.', 'warning', 10000);
        }

        function updateStats(livros) {
            document.getElementById('totalLivros').textContent = livros.length;
            document.getElementById('livrosDisponiveis').textContent = livros.filter(l => l.quantidade_disponivel > 0).length;
            document.getElementById('meusLivros').textContent = userData?.livros_atuais?.length || 0;
        }

        function updateUserUI(user) {
            document.getElementById('userName').textContent = user?.nome || 'Usuário';
        }

        function setupEventListeners() {
            document.getElementById('searchInput').addEventListener('input', (e) => {
                searchTerm = e.target.value;
                renderLivros(livrosSystem.livros);
            });
            
            document.querySelectorAll('.filter-tab').forEach(tab => {
                tab.addEventListener('click', () => {
                    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    currentFilter = tab.dataset.filter;
                    renderLivros(livrosSystem.livros);
                });
            });
            
            document.getElementById('btnProfile').addEventListener('click', () => {
                if (userData?.modoAdmin) return;
                window.location.href = 'perfil.html';
            });
            document.getElementById('btnLogout').addEventListener('click', async () => {
                if (confirm('Deseja realmente sair?')) {
                    await authSystem.logout();
                    window.location.href = 'login.html';
                }
            });
            
            document.getElementById('adminNav').addEventListener('click', () => window.location.href = 'admin.html');

            // ---- Busca: botão X (só aparece com texto), lupa do topo ----
            const searchInput = document.getElementById('searchInput');
            const btnClear = document.getElementById('btnClearSearch');
            searchInput.addEventListener('input', () => btnClear.classList.toggle('visible', searchInput.value.length > 0));
            btnClear.addEventListener('click', () => {
                searchInput.value = '';
                searchTerm = '';
                btnClear.classList.remove('visible');
                renderLivros(livrosSystem.livros);
                searchInput.focus();
            });
            document.getElementById('btnToggleSearch').addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                searchInput.focus();
            });

            // ---- Botão flutuante: volta ao topo ----
            const fab = document.getElementById('fabAction');
            fab.innerHTML = '<i class="fas fa-arrow-up"></i>';
            fab.setAttribute('aria-label', 'Voltar ao topo');
            fab.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

            // ---- Menu inferior (mobile) ----
            document.querySelectorAll('#mobileNav .nav-item[data-page]').forEach(item => {
                item.addEventListener('click', (e) => {
                    e.preventDefault();
                    const pagina = item.dataset.page;
                    if (pagina === 'catalogo') return window.scrollTo({ top: 0, behavior: 'smooth' });
                    if (userData?.modoAdmin) return showToast('Disponível apenas para alunos', 'info');
                    window.location.href = pagina === 'historico' ? 'perfil.html#historico' : 'perfil.html';
                });
            });
        }

        async function pegarLivro(livroId) {
            if (!userData || userData.modoAdmin) { showToast('Entre como aluno para emprestar livros', 'error'); return; }
            const confirmacao = await mostrarModal('Solicitar empréstimo', 'A solicitação será enviada ao administrador. O prazo de 7 dias começa após a aprovação.');
            if (!confirmacao) return;
            
            const loading = showLoading('Processando...');
            try {
                const result = await livrosSystem.pegarEmprestimo(livroId, userData.id);
                loading.close();
                if (result.success) {
                    showToast('📨 Solicitação enviada. Aguarde a aprovação do administrador.', 'success');
                    minhasSolicitacoes[livroId] = result.id;
                    await atualizarCatalogo(livrosSystem.livros);
                    updateStats(livrosSystem.livros);
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                loading.close();
                showToast('❌ Erro ao pegar livro: ' + error.message, 'error');
            }
        }

        async function devolverLivro(livroId) {
            if (!userData || userData.modoAdmin) { showToast('Entre como aluno para emprestar livros', 'error'); return; }
            const confirmacao = await mostrarModal('Confirmar Devolução', 'Tem certeza que deseja devolver este livro?');
            if (!confirmacao) return;
            
            const loading = showLoading('Devolvendo livro...');
            try {
                const result = await livrosSystem.devolverLivro(livroId, userData.id);
                loading.close();
                if (result.success) {
                    showToast('✅ Livro devolvido com sucesso!', 'success');
                    avisarConquistas(result.novasConquistas);
                    userData = await authSystem.loadUserData(userData.id);
                    await carregarMeusEmprestimos();
                    updateUserUI(userData);
                    await atualizarCatalogo(livrosSystem.livros);
                    updateStats(livrosSystem.livros);
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                loading.close();
                showToast('❌ Erro ao devolver livro: ' + error.message, 'error');
            }
        }

        async function cancelarSolicitacao(id) {
            const result = await solicitacoesEmprestimoSystem.cancelar(id);
            if (!result.success) return showToast('❌ ' + result.error, 'error');
            delete minhasSolicitacoes[Object.keys(minhasSolicitacoes).find(bookId => minhasSolicitacoes[bookId] === id)];
            showToast('Solicitação cancelada.', 'success');
            renderLivros(livrosSystem.livros);
        }

        function avisarConquistas(novas) {
            (novas || []).forEach(b => showToast(`🎉 Nova conquista: ${b.icone} ${b.nome}!`, 'success', 7000));
        }

        async function reservarLivro(livroId) {
            if (!userData || userData.modoAdmin) { showToast('Entre como aluno para reservar livros', 'error'); return; }
            const loading = showLoading('Reservando...');
            try {
                const result = await reservasSystem.reservar(livroId);
                loading.close();
                if (result.success) {
                    showToast('📌 Reserva enviada ao administrador.', 'success');
                    await atualizarCatalogo(livrosSystem.livros);
                } else {
                    showToast('❌ ' + result.error, 'error');
                }
            } catch (error) {
                loading.close();
                showToast('❌ Erro ao reservar: ' + error.message, 'error');
            }
        }

        async function cancelarReserva(livroId) {
            if (!userData || userData.modoAdmin) return;
            const ok = await mostrarModal('Cancelar reserva', 'Você sairá da fila deste livro. Deseja continuar?');
            if (!ok) return;
            const result = await reservasSystem.cancelar(livroId, userData.id);
            showToast(result.success ? '✅ Reserva cancelada' : '❌ ' + result.error, result.success ? 'success' : 'error');
            if (result.success) {
                await reservasSystem.listarMinhasAtivas(userData.id);
                await atualizarCatalogo(livrosSystem.livros);
            }
        }

        async function checkAtrasos() {
            try {
                const ativos = await emprestimosSystem.listarEmprestimosAtivos(userData.id);
                const agora = new Date();
                const atrasados = ativos.filter(e => {
                    const d = e.data_devolucao_prevista;
                    const data = d && d.toDate ? d.toDate() : new Date(d);
                    return !isNaN(data.getTime()) && data < agora;
                });
                if (atrasados.length > 0) {
                    showToast(`⚠️ Você tem ${atrasados.length} livro(s) com atraso. Regularize sua situação!`, 'warning', 10000);
                }
            } catch (error) {
                console.error('Erro ao verificar atrasos:', error);
            }
        }

        window.pegarLivro = pegarLivro;
        window.devolverLivro = devolverLivro;
        window.cancelarSolicitacao = cancelarSolicitacao;
        window.reservarLivro = reservarLivro;
        window.fecharModal = fecharModal;
        window.mostrarModal = mostrarModal;
        window.showToast = showToast;
        window.showLoading = showLoading;
