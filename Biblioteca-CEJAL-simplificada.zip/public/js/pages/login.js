let enviandoLogin = false;

        async function fazerLogin(event) {
            event.preventDefault();
            
            const matricula = document.getElementById('matricula').value.trim();
            const senha = document.getElementById('senha').value;
            const btn = event.target.querySelector('button[type="submit"]') || document.querySelector('#formLogin button, button[type="submit"]');
            
            if (!matricula || !senha) {
                showToast('Preencha todos os campos', 'error');
                return;
            }

            if (btn) { btn.disabled = true; }
            enviandoLogin = true;
            const loading = typeof showLoading === 'function' ? showLoading('Entrando...') : null;
            
            try {
                const email = `${matricula}@escola.com`.toLowerCase();
                const cred = await auth.signInWithEmailAndPassword(email, senha);

                // Papel vem SEMPRE do Firestore (nunca do nome digitado)
                const role = await authGuard.getRole(cred.user);

                if (role === 'admin') {
                    if (loading) loading.close();
                    showToast('✅ Bem-vindo, administrador!', 'success');
                    window.location.replace('admin.html');
                    return;
                }

                if (role === 'aluno') {
                    if (loading) loading.close();
                    showToast('✅ Bem-vindo(a)!', 'success');
                    window.location.replace('index.html');
                    return;
                }

                // Autenticou, mas não tem perfil em nenhuma coleção
                console.warn('Conta sem perfil. UID:', cred.user.uid);
                await auth.signOut();
                if (loading) loading.close();
                if (matricula.toLowerCase() === 'admin') {
                    showToast('❌ Conta admin sem permissão: crie o documento admins/' + cred.user.uid + ' no Firestore.', 'error');
                } else {
                    showToast('❌ Perfil de aluno não encontrado. Faça o cadastro.', 'error');
                }
            } catch (error) {
                if (loading) loading.close();
                console.error(error);
                showToast('❌ ' + authSystem.getErrorMessage(error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password'
                    ? 'auth/invalid-credential' : error.code), 'error');
            } finally {
                enviandoLogin = false;
                if (btn) { btn.disabled = false; }
            }
        }
        
        function recuperarSenha() {
            // O e-mail do aluno é fictício (matrícula@escola.com), então não há onde enviar link.
            showToast('🔑 Procure o bibliotecário para redefinir sua senha.', 'info');
        }

        // Mensagens vindas dos redirecionamentos (?erro=...)
        const MENSAGENS_ERRO = {
            'sem-perfil': 'Sua conta não tem perfil de aluno nem de administrador.',
            'perfil-incompleto': 'Seu perfil está incompleto. Procure o bibliotecário.',
            'falha-verificacao': 'Não foi possível verificar sua conta. Confira a internet e tente de novo.',
            'loop': 'Detectamos um erro de redirecionamento e encerramos a sessão. Entre novamente.'
        };

        document.addEventListener('DOMContentLoaded', async () => {
            const erro = new URLSearchParams(window.location.search).get('erro');
            if (erro) {
                // Veio de um redirecionamento com problema: mostra o motivo e NÃO redireciona de volta
                showToast('❌ ' + (MENSAGENS_ERRO[erro] || 'Não foi possível entrar.'), 'error');
                return;
            }
            // Sessão já aberta: manda UMA vez para a página certa
            if (!enviandoLogin) await authGuard.redirectIfLoggedIn();
        });
