# Biblioteca CEJAL

Sistema de biblioteca escolar com Firebase Authentication, Firestore e Hosting. Compatível com o plano Spark; não utiliza Cloud Functions nem Cloud Storage.

## Desenvolvimento local

Requer Node.js 22.

```sh
npm install
npm start
```

Auth, Firestore e Hosting usam emuladores locais. O Firebase CLI aponta o deploy para o projeto definido em `.firebaserc`; confirme esse identificador antes de publicar.

O projeto existente tem um banco Firestore nomeado `default`; o app e o deploy apontam para esse ID.

## Fluxo de empréstimo

O aluno solicita o empréstimo no catálogo. O administrador aprova ou recusa no painel. A aprovação valida bloqueio, limite, atraso, disponibilidade e reservas pendentes e registra o empréstimo e a data de devolução em uma transação Firestore. Devoluções e renovações são feitas pelo administrador.

Reservas ficam privadas para o aluno e visíveis integralmente ao administrador. No Spark, a fila e a ordem são administradas no painel; o aluno vê apenas o estado da própria reserva.

## Testes

```sh
npm test
```

A suíte verifica sintaxe, arquivos locais, configuração, índices e regras Firestore no emulador.

## Publicação no Spark

Crie ou selecione o projeto Firebase, habilite Authentication (provedor de e-mail/senha) e Firestore. Cadastre o UID do administrador em `admins/{UID}` no console do Firestore. Depois publique Hosting, regras e índices:

```sh
firebase deploy --only hosting,firestore
```

## Estrutura

- `public/`: páginas, estilos e módulos do cliente.
- `public/js/pages/`: comportamento de cada tela.
- `public/js/core/`: catálogo, empréstimos, reservas e solicitações.
- `firebase/firestore.rules`: permissões de leitura e gravação.
- `firebase/firestore.indexes.json`: índices das consultas compostas.

O documento em `admins/{UID}` é a fonte de autorização. Ele deve ser provisionado no Console Firebase por alguém com acesso administrativo ao projeto; o navegador não pode criar administradores.
